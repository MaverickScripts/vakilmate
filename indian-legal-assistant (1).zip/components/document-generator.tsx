"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { FileText, Download, Wand2, Copy, Check, Loader2 } from "lucide-react"
import { generateDocument } from "@/lib/document-service"

export default function DocumentGenerator() {
  const [documentType, setDocumentType] = useState("")
  const [formData, setFormData] = useState<Record<string, string>>({})
  const [generatedDocument, setGeneratedDocument] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)
  const [copied, setCopied] = useState(false)

  const documentTypes = [
    { value: "legal-notice", label: "Legal Notice", description: "Formal legal notice for various purposes" },
    { value: "affidavit", label: "Affidavit", description: "Sworn statement of facts" },
    { value: "power-of-attorney", label: "Power of Attorney", description: "Authorization document" },
    { value: "rental-agreement", label: "Rental Agreement", description: "Property rental contract" },
    { value: "employment-contract", label: "Employment Contract", description: "Job agreement document" },
    { value: "nda", label: "Non-Disclosure Agreement", description: "Confidentiality agreement" },
  ]

  const getFormFields = (type: string) => {
    switch (type) {
      case "legal-notice":
        return [
          { key: "senderName", label: "Sender Name", type: "text" },
          { key: "senderAddress", label: "Sender Address", type: "textarea" },
          { key: "recipientName", label: "Recipient Name", type: "text" },
          { key: "recipientAddress", label: "Recipient Address", type: "textarea" },
          { key: "subject", label: "Subject", type: "text" },
          { key: "details", label: "Details of the Issue", type: "textarea" },
          { key: "demand", label: "Demand/Request", type: "textarea" },
        ]
      case "affidavit":
        return [
          { key: "deponentName", label: "Deponent Name", type: "text" },
          { key: "deponentAddress", label: "Deponent Address", type: "textarea" },
          { key: "purpose", label: "Purpose of Affidavit", type: "text" },
          { key: "facts", label: "Statement of Facts", type: "textarea" },
        ]
      case "rental-agreement":
        return [
          { key: "landlordName", label: "Landlord Name", type: "text" },
          { key: "tenantName", label: "Tenant Name", type: "text" },
          { key: "propertyAddress", label: "Property Address", type: "textarea" },
          { key: "rentAmount", label: "Monthly Rent", type: "text" },
          { key: "securityDeposit", label: "Security Deposit", type: "text" },
          { key: "leasePeriod", label: "Lease Period", type: "text" },
        ]
      default:
        return []
    }
  }

  const handleGenerate = async () => {
    if (!documentType) return

    setIsGenerating(true)
    try {
      const document = await generateDocument(documentType, formData)
      setGeneratedDocument(document)
    } catch (error) {
      console.error("Error generating document:", error)
      setGeneratedDocument("Error generating document. Please try again.")
    } finally {
      setIsGenerating(false)
    }
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedDocument)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div className="space-y-8">
      <div className="text-center mb-12">
        <div className="flex items-center justify-center gap-3 mb-6">
          <FileText className="h-10 w-10 text-red-600" />
          <h2 className="text-4xl font-bold">Legal Document Generator</h2>
        </div>
        <p className="text-muted-foreground max-w-3xl mx-auto text-lg leading-relaxed">
          Generate professional legal documents instantly. Choose from various templates and customize them according to
          your needs.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Document Selection & Form */}
        <Card className="p-8 space-y-8 bg-gradient-to-br from-white to-slate-50 dark:from-slate-800 dark:to-slate-900">
          <div>
            <h3 className="text-2xl font-semibold mb-6">Select Document Type</h3>
            <div className="grid grid-cols-1 gap-4">
              {documentTypes.map((type) => (
                <Card
                  key={type.value}
                  className={`p-6 cursor-pointer transition-all hover:shadow-lg ${
                    documentType === type.value ? "ring-2 ring-red-600 bg-red-50 dark:bg-red-950/20" : ""
                  }`}
                  onClick={() => setDocumentType(type.value)}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-lg">{type.label}</h4>
                      <p className="text-base text-muted-foreground mt-1">{type.description}</p>
                    </div>
                    <Badge variant={documentType === type.value ? "default" : "outline"} className="px-3 py-1">
                      {documentType === type.value ? "Selected" : "Select"}
                    </Badge>
                  </div>
                </Card>
              ))}
            </div>
          </div>

          {documentType && (
            <div>
              <h3 className="text-2xl font-semibold mb-6">Document Details</h3>
              <div className="space-y-6">
                {getFormFields(documentType).map((field) => (
                  <div key={field.key}>
                    <label className="block text-base font-medium mb-3">{field.label}</label>
                    {field.type === "textarea" ? (
                      <Textarea
                        placeholder={`Enter ${field.label.toLowerCase()}`}
                        value={formData[field.key] || ""}
                        onChange={(e) => setFormData((prev) => ({ ...prev, [field.key]: e.target.value }))}
                        className="min-h-[100px] text-base"
                      />
                    ) : (
                      <Input
                        placeholder={`Enter ${field.label.toLowerCase()}`}
                        value={formData[field.key] || ""}
                        onChange={(e) => setFormData((prev) => ({ ...prev, [field.key]: e.target.value }))}
                        className="h-12 text-base"
                      />
                    )}
                  </div>
                ))}

                <Button
                  onClick={handleGenerate}
                  disabled={isGenerating}
                  className="w-full bg-red-600 hover:bg-red-700 h-12 text-base"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                      Generating Document...
                    </>
                  ) : (
                    <>
                      <Wand2 className="mr-2 h-5 w-5" />
                      Generate Document
                    </>
                  )}
                </Button>
              </div>
            </div>
          )}
        </Card>

        {/* Generated Document Preview */}
        <Card className="p-8 bg-gradient-to-br from-white to-slate-50 dark:from-slate-800 dark:to-slate-900">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-2xl font-semibold">Document Preview</h3>
            {generatedDocument && (
              <div className="flex gap-3">
                <Button variant="outline" size="sm" onClick={copyToClipboard} className="h-10">
                  {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                </Button>
                <Button variant="outline" size="sm" className="h-10">
                  <Download className="h-4 w-4" />
                </Button>
              </div>
            )}
          </div>

          {!generatedDocument ? (
            <div className="text-center py-20 text-muted-foreground">
              <FileText className="h-16 w-16 mx-auto mb-6 opacity-50" />
              <p className="text-lg">Select a document type and fill in the details to generate your legal document</p>
            </div>
          ) : (
            <div className="bg-white dark:bg-slate-900 border rounded-lg p-8 min-h-[500px] font-mono text-sm whitespace-pre-wrap leading-relaxed shadow-inner">
              {generatedDocument}
            </div>
          )}
        </Card>
      </div>
    </div>
  )
}
