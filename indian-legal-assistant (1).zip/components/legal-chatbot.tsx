"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Send, Bot, User, MessageSquare, Loader2, Sparkles, Zap, Clock, CheckCircle } from "lucide-react"
import { generateChatResponse } from "@/lib/chat-service"

interface Message {
  id: string
  content: string
  role: "user" | "assistant"
  timestamp: Date
}

export default function LegalChatbot() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      content:
        "🙏 Namaste! I'm your AI Legal Assistant from Vakil Mate, specialized in Indian law. I can help you with:\n\n• Legal procedures (FIR, bail, complaints)\n• IPC sections and criminal law\n• Rights of accused persons\n• Court procedures and jurisdiction\n• Legal definitions and concepts\n\nHow can I assist you with your legal query today?",
      role: "assistant",
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSend = async () => {
    if (!input.trim() || isLoading) return

    const userMessage: Message = {
      id: Date.now().toString(),
      content: input,
      role: "user",
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    try {
      const response = await generateChatResponse(input, messages)
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: response,
        role: "assistant",
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, assistantMessage])
    } catch (error) {
      console.error("Error generating response:", error)
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        content:
          "I apologize, but I'm having trouble processing your request right now. Please try again in a moment. For urgent legal matters, please consult with a qualified lawyer immediately.",
        role: "assistant",
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, errorMessage])
    } finally {
      setIsLoading(false)
    }
  }

  const quickQuestions = [
    { question: "How to file an FIR?", icon: "📋" },
    { question: "Explain Section 420 IPC", icon: "⚖️" },
    { question: "Rights of accused person", icon: "🛡️" },
    { question: "Consumer complaint procedure", icon: "🏛️" },
    { question: "What is anticipatory bail?", icon: "🔓" },
    { question: "Cognizable vs non-cognizable", icon: "📚" },
  ]

  return (
    <div className="space-y-10">
      <div className="text-center mb-16">
        <div className="flex items-center justify-center gap-4 mb-8">
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-green-500 to-green-600 rounded-3xl blur opacity-75 pulse-glow"></div>
            <div className="relative p-4 bg-gradient-to-r from-green-500 to-green-600 rounded-3xl">
              <MessageSquare className="h-12 w-12 text-white" />
            </div>
          </div>
          <h2 className="text-5xl font-display font-bold gradient-text">AI Legal Chatbot</h2>
        </div>
        <p className="text-muted-foreground max-w-4xl mx-auto text-xl leading-relaxed mb-8">
          Get instant answers to your legal questions from our AI assistant trained on Indian law. Ask about procedures,
          rights, legal definitions, and more with professional guidance.
        </p>
        <div className="flex flex-wrap justify-center gap-4">
          <Badge className="bg-gradient-to-r from-green-500 to-green-600 text-white px-6 py-3 text-lg shadow-lg">
            <Sparkles className="h-5 w-5 mr-2" />
            24/7 Available
          </Badge>
          <Badge className="bg-gradient-to-r from-blue-500 to-blue-600 text-white px-6 py-3 text-lg shadow-lg">
            <Zap className="h-5 w-5 mr-2" />
            Instant Responses
          </Badge>
          <Badge className="bg-gradient-to-r from-purple-500 to-purple-600 text-white px-6 py-3 text-lg shadow-lg">
            <CheckCircle className="h-5 w-5 mr-2" />
            Expert Knowledge
          </Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-6 lg:gap-8">
        {/* Quick Questions Sidebar */}
        <Card className="xl:col-span-1 glass-card p-4 lg:p-8 rounded-2xl order-2 xl:order-1">
          <h3 className="font-display font-semibold mb-4 lg:mb-8 text-xl lg:text-2xl flex items-center gap-3">
            <Zap className="h-5 w-5 lg:h-6 lg:w-6 text-orange-600" />
            Quick Questions
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-1 gap-3 lg:gap-4">
            {quickQuestions.map((item, index) => (
              <Button
                key={index}
                variant="ghost"
                size="sm"
                className="w-full text-left justify-start h-auto p-3 lg:p-4 text-wrap border-2 border-dashed border-gray-200 hover:border-red-400 hover:bg-red-50 dark:hover:bg-red-950/20 transition-all duration-300 rounded-xl"
                onClick={() => setInput(item.question)}
              >
                <span className="text-xl lg:text-2xl mr-2 lg:mr-3">{item.icon}</span>
                <span className="font-medium text-sm lg:text-base">{item.question}</span>
              </Button>
            ))}
          </div>
        </Card>

        {/* Chat Interface */}
        <Card className="xl:col-span-3 flex flex-col h-[600px] lg:h-[800px] glass-card rounded-2xl overflow-hidden shadow-2xl order-1 xl:order-2">
          {/* Chat Header */}
          <div className="p-4 lg:p-8 bg-gradient-to-r from-red-50 via-white to-red-50 dark:from-red-950/20 dark:via-slate-900 dark:to-red-950/20 border-b">
            <div className="flex items-center gap-4 lg:gap-6">
              <div className="relative">
                <Avatar className="h-12 w-12 lg:h-16 lg:w-16 ring-4 ring-red-200 dark:ring-red-800">
                  <AvatarFallback className="bg-gradient-to-r from-red-600 to-red-700 text-white text-lg lg:text-xl">
                    <Bot className="h-6 w-6 lg:h-8 lg:w-8" />
                  </AvatarFallback>
                </Avatar>
                <div className="absolute -bottom-1 -right-1 h-4 w-4 lg:h-6 lg:w-6 bg-green-500 rounded-full border-2 border-white flex items-center justify-center">
                  <div className="h-1.5 w-1.5 lg:h-2 lg:w-2 bg-white rounded-full"></div>
                </div>
              </div>
              <div>
                <h3 className="font-display font-semibold text-xl lg:text-2xl">Vakil Mate AI Assistant</h3>
                <div className="flex items-center gap-2 text-muted-foreground text-sm lg:text-base">
                  <div className="h-2 w-2 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="font-medium">Online • Specialized in Indian Law</span>
                </div>
              </div>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 lg:p-8 space-y-4 lg:space-y-8 bg-gradient-to-b from-white to-slate-50 dark:from-slate-900 dark:to-slate-800">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-3 lg:gap-6 ${message.role === "user" ? "justify-end" : "justify-start"}`}
              >
                {message.role === "assistant" && (
                  <Avatar className="h-8 w-8 lg:h-12 lg:w-12 mt-1 ring-2 ring-red-200 dark:ring-red-800 flex-shrink-0">
                    <AvatarFallback className="bg-gradient-to-r from-red-600 to-red-700 text-white">
                      <Bot className="h-4 w-4 lg:h-6 lg:w-6" />
                    </AvatarFallback>
                  </Avatar>
                )}
                <div
                  className={`max-w-[85%] lg:max-w-[80%] rounded-2xl p-4 lg:p-6 shadow-lg ${
                    message.role === "user"
                      ? "bg-gradient-to-r from-red-600 to-red-700 text-white"
                      : "glass-card border"
                  }`}
                >
                  <p className="text-sm lg:text-base whitespace-pre-wrap leading-relaxed font-medium">
                    {message.content}
                  </p>
                  <div className="flex items-center gap-2 mt-3 lg:mt-4">
                    <Clock className="h-3 w-3 opacity-70" />
                    <p className={`text-xs ${message.role === "user" ? "text-red-100" : "text-muted-foreground"}`}>
                      {message.timestamp.toLocaleTimeString()}
                    </p>
                  </div>
                </div>
                {message.role === "user" && (
                  <Avatar className="h-8 w-8 lg:h-12 lg:w-12 mt-1 ring-2 ring-blue-200 dark:ring-blue-800 flex-shrink-0">
                    <AvatarFallback className="bg-gradient-to-r from-blue-600 to-blue-700 text-white">
                      <User className="h-4 w-4 lg:h-6 lg:w-6" />
                    </AvatarFallback>
                  </Avatar>
                )}
              </div>
            ))}
            {isLoading && (
              <div className="flex gap-6 justify-start">
                <Avatar className="h-12 w-12 mt-1 ring-2 ring-red-200 dark:ring-red-800">
                  <AvatarFallback className="bg-gradient-to-r from-red-600 to-red-700 text-white">
                    <Bot className="h-6 w-6" />
                  </AvatarFallback>
                </Avatar>
                <div className="glass-card rounded-2xl p-6 border shadow-lg">
                  <div className="flex items-center gap-4">
                    <Loader2 className="h-6 w-6 animate-spin text-red-600" />
                    <span className="text-base font-medium">AI is thinking...</span>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-4 lg:p-8 bg-gradient-to-r from-slate-50 via-white to-slate-50 dark:from-slate-800 dark:via-slate-900 dark:to-slate-800 border-t">
            <div className="flex gap-3 lg:gap-4">
              <Input
                placeholder="Ask me anything about Indian law..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleSend()}
                disabled={isLoading}
                className="text-base lg:text-lg h-12 lg:h-14 px-4 lg:px-6 border-2 focus:border-red-500 rounded-xl"
              />
              <Button
                onClick={handleSend}
                disabled={isLoading || !input.trim()}
                className="btn-primary h-12 lg:h-14 px-6 lg:px-8 rounded-xl flex-shrink-0"
              >
                <Send className="h-5 w-5 lg:h-6 lg:w-6" />
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}
