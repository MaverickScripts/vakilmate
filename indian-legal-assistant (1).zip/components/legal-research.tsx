"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BookOpen, Search, FileText, Scale, Users, ExternalLink, Loader2 } from "lucide-react"
import { searchLegalContent } from "@/lib/research-service"

export default function LegalResearch() {
  const [searchQuery, setSearchQuery] = useState("")
  const [isSearching, setIsSearching] = useState(false)
  const [searchResults, setSearchResults] = useState<any[]>([])

  const handleSearch = async () => {
    if (!searchQuery.trim()) return

    setIsSearching(true)
    try {
      const results = await searchLegalContent(searchQuery)
      setSearchResults(results)
    } catch (error) {
      console.error("Error searching:", error)
    } finally {
      setIsSearching(false)
    }
  }

  const ipcSections = [
    {
      section: "Section 302",
      title: "Punishment for murder",
      description:
        "Whoever commits murder shall be punished with death, or imprisonment for life, and shall also be liable to fine.",
      category: "Offences against the Human Body",
      relatedSections: ["300", "301", "303", "304"],
      punishment: "Death or Life Imprisonment + Fine",
      cognizable: "Yes",
      bailable: "No",
    },
    {
      section: "Section 420",
      title: "Cheating and dishonestly inducing delivery of property",
      description:
        "Whoever cheats and thereby dishonestly induces the person deceived to deliver any property to any person, or to make, alter or destroy the whole or any part of a valuable security, or anything which is signed or sealed, and which is capable of being converted into a valuable security, shall be punished with imprisonment of either description for a term which may extend to seven years, and shall also be liable to fine.",
      category: "Of Cheating",
      relatedSections: ["415", "416", "417", "418", "419"],
      punishment: "Imprisonment up to 7 years + Fine",
      cognizable: "No",
      bailable: "Yes",
    },
    {
      section: "Section 498A",
      title: "Husband or relative of husband of a woman subjecting her to cruelty",
      description:
        "Whoever, being the husband or the relative of the husband of a woman, subjects such woman to cruelty shall be punished with imprisonment for a term which may extend to three years and shall also be liable to fine.",
      category: "Offences against Women",
      relatedSections: ["304B", "306", "113A", "113B"],
      punishment: "Imprisonment up to 3 years + Fine",
      cognizable: "Yes",
      bailable: "No",
    },
  ]

  const legalPrinciples = [
    {
      principle: "Presumption of Innocence",
      description: "Every person is presumed innocent until proven guilty beyond reasonable doubt",
      application: "Criminal Law",
      cases: ["Woolmington v DPP", "State of UP v Krishna Gopal"],
      latinMaxim: "Ei incumbit probatio qui dicit, non qui negat",
    },
    {
      principle: "Natural Justice",
      description:
        "No one should be condemned unheard (audi alteram partem) and no one should be a judge in his own cause (nemo judex in causa sua)",
      application: "Administrative Law",
      cases: ["Ridge v Baldwin", "Maneka Gandhi v Union of India"],
      latinMaxim: "Audi alteram partem",
    },
    {
      principle: "Res Judicata",
      description: "A matter once decided should not be reopened",
      application: "Civil Procedure",
      cases: ["Daryao v State of UP", "Mathura Prasad v Dossibai"],
      latinMaxim: "Res judicata pro veritate accipitur",
    },
  ]

  const legalMaxims = [
    {
      latin: "Actus reus non facit reum nisi mens sit rea",
      english: "The act is not culpable unless the mind is guilty",
      explanation:
        "Both guilty act and guilty mind are required for a crime. This is the foundation of criminal liability in most legal systems.",
      area: "Criminal Law",
      application: "Used to determine criminal liability",
    },
    {
      latin: "Ignorantia juris non excusat",
      english: "Ignorance of law is no excuse",
      explanation:
        "Not knowing the law does not exempt one from following it. Every citizen is presumed to know the law.",
      area: "General Law",
      application: "Applied in all legal proceedings",
    },
    {
      latin: "Nemo judex in causa sua",
      english: "No one should be a judge in his own cause",
      explanation:
        "A person cannot judge a case in which they have an interest. This ensures impartiality in judicial proceedings.",
      area: "Natural Justice",
      application: "Administrative and judicial proceedings",
    },
  ]

  return (
    <div className="space-y-8">
      <div className="text-center mb-12">
        <div className="flex items-center justify-center gap-3 mb-6">
          <BookOpen className="h-10 w-10 text-red-600" />
          <h2 className="text-4xl font-bold">Legal Research Hub</h2>
        </div>
        <p className="text-muted-foreground max-w-3xl mx-auto text-lg leading-relaxed">
          Comprehensive legal research tools including IPC sections, legal principles, maxims, and procedural guidelines
          for Indian law practitioners.
        </p>
      </div>

      {/* Search Bar */}
      <Card className="p-6 bg-gradient-to-br from-white to-slate-50 dark:from-slate-800 dark:to-slate-900">
        <div className="flex gap-3">
          <Input
            placeholder="Search IPC sections, legal principles, maxims..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="flex-1 h-12 text-base"
            onKeyPress={(e) => e.key === "Enter" && handleSearch()}
          />
          <Button onClick={handleSearch} disabled={isSearching} className="bg-red-600 hover:bg-red-700 h-12 px-6">
            {isSearching ? (
              <Loader2 className="h-5 w-5 animate-spin" />
            ) : (
              <>
                <Search className="h-5 w-5 mr-2" />
                Search
              </>
            )}
          </Button>
        </div>
      </Card>

      <Tabs defaultValue="ipc" className="w-full">
        <TabsList className="grid w-full grid-cols-4 h-14 bg-white dark:bg-slate-800 shadow-sm">
          <TabsTrigger value="ipc" className="text-base">
            IPC Sections
          </TabsTrigger>
          <TabsTrigger value="principles" className="text-base">
            Legal Principles
          </TabsTrigger>
          <TabsTrigger value="maxims" className="text-base">
            Legal Maxims
          </TabsTrigger>
          <TabsTrigger value="procedures" className="text-base">
            Procedures
          </TabsTrigger>
        </TabsList>

        <TabsContent value="ipc" className="space-y-6 mt-8">
          <div className="flex items-center justify-between">
            <h3 className="text-2xl font-semibold">Indian Penal Code Sections</h3>
            <Badge variant="secondary" className="px-4 py-2">
              {ipcSections.length} sections
            </Badge>
          </div>

          {ipcSections.map((section, index) => (
            <Card
              key={index}
              className="p-8 bg-gradient-to-br from-white to-slate-50 dark:from-slate-800 dark:to-slate-900 hover:shadow-lg transition-shadow"
            >
              <div className="space-y-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-4">
                      <Badge className="bg-red-600 px-4 py-2 text-base">{section.section}</Badge>
                      <Badge variant="outline" className="px-3 py-1">
                        {section.category}
                      </Badge>
                    </div>
                    <h4 className="text-xl font-semibold mb-4">{section.title}</h4>
                    <p className="text-muted-foreground text-base leading-relaxed">{section.description}</p>
                  </div>
                  <Button variant="outline" size="sm" className="h-10">
                    <ExternalLink className="h-4 w-4" />
                  </Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div>
                    <p className="text-base font-medium mb-3">Punishment:</p>
                    <Badge variant="secondary" className="px-3 py-1">
                      {section.punishment}
                    </Badge>
                  </div>
                  <div>
                    <p className="text-base font-medium mb-3">Cognizable:</p>
                    <Badge variant={section.cognizable === "Yes" ? "destructive" : "outline"} className="px-3 py-1">
                      {section.cognizable}
                    </Badge>
                  </div>
                  <div>
                    <p className="text-base font-medium mb-3">Bailable:</p>
                    <Badge variant={section.bailable === "Yes" ? "outline" : "destructive"} className="px-3 py-1">
                      {section.bailable}
                    </Badge>
                  </div>
                </div>

                <div>
                  <p className="text-base font-medium mb-3">Related Sections:</p>
                  <div className="flex gap-2 flex-wrap">
                    {section.relatedSections.map((related, idx) => (
                      <Badge key={idx} variant="secondary" className="text-sm px-3 py-1">
                        Section {related}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="principles" className="space-y-6 mt-8">
          <div className="flex items-center justify-between">
            <h3 className="text-2xl font-semibold">Fundamental Legal Principles</h3>
            <Badge variant="secondary" className="px-4 py-2">
              {legalPrinciples.length} principles
            </Badge>
          </div>

          {legalPrinciples.map((principle, index) => (
            <Card
              key={index}
              className="p-8 bg-gradient-to-br from-white to-slate-50 dark:from-slate-800 dark:to-slate-900 hover:shadow-lg transition-shadow"
            >
              <div className="space-y-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-4">
                      <Scale className="h-6 w-6 text-red-600" />
                      <h4 className="text-xl font-semibold">{principle.principle}</h4>
                    </div>
                    <p className="text-muted-foreground mb-4 text-base leading-relaxed">{principle.description}</p>
                    <div className="flex gap-3">
                      <Badge variant="outline" className="px-3 py-1">
                        {principle.application}
                      </Badge>
                      <Badge variant="secondary" className="px-3 py-1 italic">
                        {principle.latinMaxim}
                      </Badge>
                    </div>
                  </div>
                </div>

                <div>
                  <p className="text-base font-medium mb-3">Landmark Cases:</p>
                  <div className="flex flex-wrap gap-2">
                    {principle.cases.map((case_, idx) => (
                      <Badge key={idx} variant="secondary" className="text-sm px-3 py-1">
                        {case_}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="maxims" className="space-y-6 mt-8">
          <div className="flex items-center justify-between">
            <h3 className="text-2xl font-semibold">Legal Maxims</h3>
            <Badge variant="secondary" className="px-4 py-2">
              {legalMaxims.length} maxims
            </Badge>
          </div>

          {legalMaxims.map((maxim, index) => (
            <Card
              key={index}
              className="p-8 bg-gradient-to-br from-white to-slate-50 dark:from-slate-800 dark:to-slate-900 hover:shadow-lg transition-shadow"
            >
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <FileText className="h-6 w-6 text-red-600" />
                  <Badge variant="outline" className="px-3 py-1">
                    {maxim.area}
                  </Badge>
                </div>
                <div>
                  <h4 className="text-xl font-semibold italic text-red-700 mb-2">{maxim.latin}</h4>
                  <p className="font-medium mb-3 text-lg">{maxim.english}</p>
                  <p className="text-muted-foreground text-base leading-relaxed mb-3">{maxim.explanation}</p>
                  <Badge variant="secondary" className="px-3 py-1">
                    Application: {maxim.application}
                  </Badge>
                </div>
              </div>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="procedures" className="space-y-6 mt-8">
          <div className="text-center py-20">
            <Users className="h-16 w-16 mx-auto mb-6 text-muted-foreground" />
            <h3 className="text-2xl font-semibold mb-4">Legal Procedures</h3>
            <p className="text-muted-foreground text-lg mb-8 max-w-2xl mx-auto">
              Comprehensive guides for legal procedures, court processes, and filing requirements coming soon.
            </p>
            <Button className="bg-red-600 hover:bg-red-700 px-8 py-3 text-base">Coming Soon</Button>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
