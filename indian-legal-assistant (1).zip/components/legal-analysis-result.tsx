import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { AlertTriangle, CheckCircle, BookOpen, Shield, Gavel, FileText } from "lucide-react"

interface LegalAnalysisResultProps {
  analysis: {
    summary: string
    crimeDetected: boolean
    crimes?: string[]
    ipcSections?: { section: string; description: string }[]
    explanation?: string
    possibleDefenses?: string[]
    legalAdvice?: string
    references?: string[]
  }
}

export default function LegalAnalysisResult({ analysis }: LegalAnalysisResultProps) {
  return (
    <div className="space-y-6">
      <section>
        <h3 className="text-lg font-semibold mb-2 flex items-center gap-2">
          <FileText className="h-5 w-5" />
          Summary
        </h3>
        <Card className="p-4 bg-muted/50">
          <p>{analysis.summary}</p>
        </Card>
      </section>

      <section>
        <div className="flex items-center gap-2 mb-2">
          <h3 className="text-lg font-semibold">Crime Detection</h3>
          {analysis.crimeDetected ? (
            <Badge variant="destructive" className="flex items-center gap-1">
              <AlertTriangle className="h-3 w-3" />
              Crime Detected
            </Badge>
          ) : (
            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200 flex items-center gap-1">
              <CheckCircle className="h-3 w-3" />
              No Crime Detected
            </Badge>
          )}
        </div>

        {analysis.crimeDetected && analysis.crimes && (
          <div className="mb-4">
            <p className="text-sm text-muted-foreground mb-2">Identified crimes:</p>
            <div className="flex flex-wrap gap-2">
              {analysis.crimes.map((crime, index) => (
                <Badge key={index} variant="secondary">
                  {crime}
                </Badge>
              ))}
            </div>
          </div>
        )}
      </section>

      {analysis.ipcSections && analysis.ipcSections.length > 0 && (
        <section>
          <h3 className="text-lg font-semibold mb-2 flex items-center gap-2">
            <BookOpen className="h-5 w-5" />
            Relevant IPC Section(s)
          </h3>
          <div className="space-y-3">
            {analysis.ipcSections.map((section, index) => (
              <Card key={index} className="p-4 border-l-4 border-l-red-600">
                <p className="font-semibold">{section.section}</p>
                <p className="text-sm text-muted-foreground">{section.description}</p>
              </Card>
            ))}
          </div>
        </section>
      )}

      {analysis.explanation && (
        <section>
          <h3 className="text-lg font-semibold mb-2">Explanation</h3>
          <Card className="p-4">
            <p>{analysis.explanation}</p>
          </Card>
        </section>
      )}

      {analysis.possibleDefenses && analysis.possibleDefenses.length > 0 && (
        <section>
          <h3 className="text-lg font-semibold mb-2 flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Possible Defenses
          </h3>
          <ul className="list-disc pl-5 space-y-2">
            {analysis.possibleDefenses.map((defense, index) => (
              <li key={index}>{defense}</li>
            ))}
          </ul>
        </section>
      )}

      {analysis.legalAdvice && (
        <section>
          <h3 className="text-lg font-semibold mb-2 flex items-center gap-2">
            <Gavel className="h-5 w-5" />
            Legal Advice / How to Win
          </h3>
          <Card className="p-4 bg-muted/50">
            <p>{analysis.legalAdvice}</p>
          </Card>
        </section>
      )}

      {analysis.references && analysis.references.length > 0 && (
        <section>
          <h3 className="text-lg font-semibold mb-2">References</h3>
          <div className="text-sm space-y-1">
            {analysis.references.map((reference, index) => (
              <p key={index} className="text-muted-foreground">
                {reference}
              </p>
            ))}
          </div>
        </section>
      )}
    </div>
  )
}
