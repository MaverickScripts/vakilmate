"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Loader2,
  Upload,
  FileText,
  AlertTriangle,
  CheckCircle,
  BookOpen,
  Shield,
  Gavel,
  Brain,
  Sparkles,
  Zap,
} from "lucide-react"
import { generateLegalAnalysis } from "@/lib/generate-analysis"

export default function LegalAnalyzer() {
  const [input, setInput] = useState("")
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [result, setResult] = useState<any>(null)

  const handleAnalyze = async () => {
    if (!input.trim()) return

    setIsAnalyzing(true)
    try {
      const analysis = await generateLegalAnalysis(input)
      setResult(analysis)
    } catch (error) {
      console.error("Error analyzing text:", error)
      setResult({
        summary: "Error occurred during analysis. Please try again.",
        crimeDetected: false,
        explanation: "Unable to process the request at this time.",
      })
    } finally {
      setIsAnalyzing(false)
    }
  }

  const sampleCases = [
    {
      text: "A person was caught stealing a mobile phone from a shop. What are the legal implications?",
      icon: "📱",
      category: "Theft",
    },
    {
      text: "Someone threatened to harm me and my family. Is this a criminal offense?",
      icon: "⚠️",
      category: "Threat",
    },
    {
      text: "A person was driving under the influence and caused an accident. What charges can be filed?",
      icon: "🚗",
      category: "DUI",
    },
  ]

  return (
    <div className="space-y-12">
      <div className="text-center mb-16">
        <div className="flex items-center justify-center gap-4 mb-8">
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-blue-600 rounded-3xl blur opacity-75 pulse-glow"></div>
            <div className="relative p-4 bg-gradient-to-r from-blue-500 to-blue-600 rounded-3xl">
              <Brain className="h-12 w-12 text-white" />
            </div>
          </div>
          <h2 className="text-responsive-2xl font-display font-bold gradient-text">AI Legal Document Analyzer</h2>
        </div>
        <p className="text-muted-foreground max-w-4xl mx-auto text-xl leading-relaxed mb-8">
          Upload or paste legal documents, case descriptions, or scenarios for comprehensive AI-powered analysis based
          on Indian Penal Code and legal precedents.
        </p>
        <div className="flex flex-wrap justify-center gap-4">
          <Badge className="bg-gradient-to-r from-blue-500 to-blue-600 text-white px-6 py-3 text-lg shadow-lg">
            <Sparkles className="h-5 w-5 mr-2" />
            AI Powered
          </Badge>
          <Badge className="bg-gradient-to-r from-green-500 to-green-600 text-white px-6 py-3 text-lg shadow-lg">
            <Zap className="h-5 w-5 mr-2" />
            Instant Analysis
          </Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 lg:gap-10">
        {/* Input Section */}
        <Card className="glass-card p-6 lg:p-10 rounded-3xl">
          <div className="flex items-center gap-3 lg:gap-4 mb-6 lg:mb-8">
            <div className="p-2 lg:p-3 bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl lg:rounded-2xl">
              <FileText className="h-6 w-6 lg:h-8 lg:w-8 text-white" />
            </div>
            <h3 className="text-2xl lg:text-3xl font-display font-semibold">Input Legal Text</h3>
          </div>

          <div className="space-y-6 lg:space-y-8">
            <Textarea
              placeholder="Describe the legal situation, paste case details, or upload a document..."
              className="min-h-[200px] lg:min-h-[300px] resize-none text-base lg:text-lg p-4 lg:p-6 border-2 focus:border-blue-500 rounded-2xl"
              value={input}
              onChange={(e) => setInput(e.target.value)}
            />

            <div className="flex flex-col sm:flex-row gap-3 lg:gap-4">
              <Button
                onClick={handleAnalyze}
                disabled={isAnalyzing || !input.trim()}
                className="btn-primary flex-1 h-12 lg:h-16 text-base lg:text-lg rounded-2xl"
              >
                {isAnalyzing ? (
                  <>
                    <Loader2 className="mr-2 lg:mr-3 h-5 w-5 lg:h-6 lg:w-6 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Brain className="mr-2 lg:mr-3 h-5 w-5 lg:h-6 lg:w-6" />
                    Analyze with AI
                  </>
                )}
              </Button>
              <Button variant="outline" className="px-6 lg:px-8 h-12 lg:h-16 rounded-2xl border-2 sm:w-auto">
                <Upload className="h-5 w-5 lg:h-6 lg:w-6" />
              </Button>
            </div>
          </div>

          {/* Sample Cases */}
          <div className="space-y-4 lg:space-y-6 mt-8 lg:mt-10">
            <p className="text-base lg:text-lg font-semibold text-muted-foreground">Try these sample cases:</p>
            <div className="space-y-3 lg:space-y-4">
              {sampleCases.map((sample, index) => (
                <Button
                  key={index}
                  variant="ghost"
                  size="sm"
                  className="w-full text-left justify-start h-auto p-4 lg:p-6 text-wrap border-2 border-dashed hover:border-solid hover:bg-blue-50 dark:hover:bg-blue-950/20 rounded-2xl transition-all duration-300"
                  onClick={() => setInput(sample.text)}
                >
                  <div className="flex items-start gap-3 lg:gap-4">
                    <span className="text-2xl lg:text-3xl flex-shrink-0">{sample.icon}</span>
                    <div>
                      <Badge variant="outline" className="mb-2">
                        {sample.category}
                      </Badge>
                      <p className="text-sm lg:text-base">{sample.text}</p>
                    </div>
                  </div>
                </Button>
              ))}
            </div>
          </div>
        </Card>

        {/* Results Section */}
        <Card className="glass-card p-6 lg:p-10 rounded-3xl">
          <div className="flex items-center gap-3 lg:gap-4 mb-6 lg:mb-8">
            <div className="p-2 lg:p-3 bg-gradient-to-r from-green-500 to-green-600 rounded-xl lg:rounded-2xl">
              <Gavel className="h-6 w-6 lg:h-8 lg:w-8 text-white" />
            </div>
            <h3 className="text-2xl lg:text-3xl font-display font-semibold">Analysis Results</h3>
          </div>

          {!result ? (
            <div className="text-center py-20 text-muted-foreground">
              <div className="relative mb-8">
                <div className="absolute inset-0 bg-gradient-to-r from-gray-200 to-gray-300 dark:from-gray-700 dark:to-gray-600 rounded-full blur opacity-50"></div>
                <div className="relative p-6 bg-gradient-to-r from-gray-200 to-gray-300 dark:from-gray-700 dark:to-gray-600 rounded-full w-fit mx-auto">
                  <Brain className="h-16 w-16 text-gray-500" />
                </div>
              </div>
              <p className="text-xl font-medium">
                Enter legal text and click "Analyze with AI" to get comprehensive legal analysis
              </p>
            </div>
          ) : (
            <div className="space-y-8">
              {/* Crime Detection Status */}
              <div className="flex items-center gap-4">
                {result.crimeDetected ? (
                  <Badge variant="destructive" className="flex items-center gap-3 px-6 py-3 text-lg rounded-xl">
                    <AlertTriangle className="h-5 w-5" />
                    Crime Detected
                  </Badge>
                ) : (
                  <Badge
                    variant="outline"
                    className="bg-green-50 text-green-700 border-green-200 flex items-center gap-3 px-6 py-3 text-lg rounded-xl"
                  >
                    <CheckCircle className="h-5 w-5" />
                    No Crime Detected
                  </Badge>
                )}
              </div>

              {/* Summary */}
              <div>
                <h4 className="font-semibold mb-4 flex items-center gap-3 text-xl">
                  <FileText className="h-6 w-6 text-blue-600" />
                  Summary
                </h4>
                <Card className="p-6 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-950/20 dark:to-indigo-950/20 rounded-2xl border-0">
                  <p className="text-lg leading-relaxed">{result.summary}</p>
                </Card>
              </div>

              {/* Crimes Identified */}
              {result.crimes && result.crimes.length > 0 && (
                <div>
                  <h4 className="font-semibold mb-4 text-xl">Crimes Identified</h4>
                  <div className="flex flex-wrap gap-3">
                    {result.crimes.map((crime: string, index: number) => (
                      <Badge key={index} variant="secondary" className="px-4 py-2 text-base rounded-xl">
                        {crime}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {/* IPC Sections */}
              {result.ipcSections && result.ipcSections.length > 0 && (
                <div>
                  <h4 className="font-semibold mb-4 flex items-center gap-3 text-xl">
                    <BookOpen className="h-6 w-6 text-purple-600" />
                    Relevant IPC Sections
                  </h4>
                  <div className="space-y-4">
                    {result.ipcSections.map((section: any, index: number) => (
                      <Card key={index} className="p-6 border-l-4 border-l-red-600 rounded-2xl">
                        <p className="font-semibold text-lg mb-2">{section.section}</p>
                        <p className="text-muted-foreground leading-relaxed">{section.description}</p>
                      </Card>
                    ))}
                  </div>
                </div>
              )}

              {/* Possible Defenses */}
              {result.possibleDefenses && result.possibleDefenses.length > 0 && (
                <div>
                  <h4 className="font-semibold mb-4 flex items-center gap-3 text-xl">
                    <Shield className="h-6 w-6 text-green-600" />
                    Possible Defenses
                  </h4>
                  <ul className="list-disc pl-8 space-y-3 text-lg">
                    {result.possibleDefenses.map((defense: string, index: number) => (
                      <li key={index} className="leading-relaxed">
                        {defense}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Legal Advice */}
              {result.legalAdvice && (
                <div>
                  <h4 className="font-semibold mb-4 flex items-center gap-3 text-xl">
                    <Gavel className="h-6 w-6 text-orange-600" />
                    Legal Advice
                  </h4>
                  <Card className="p-6 bg-gradient-to-r from-orange-50 to-yellow-50 dark:from-orange-950/20 dark:to-yellow-950/20 rounded-2xl border-0">
                    <p className="text-lg leading-relaxed">{result.legalAdvice}</p>
                  </Card>
                </div>
              )}
            </div>
          )}
        </Card>
      </div>
    </div>
  )
}
