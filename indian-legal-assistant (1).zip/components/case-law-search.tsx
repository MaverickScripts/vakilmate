"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Calendar, MapPin, ExternalLink, BookOpen, Loader2, Scale, Users, FileText } from "lucide-react"
import { searchCaseLaws } from "@/lib/case-search-service"

export default function CaseLawSearch() {
  const [searchQuery, setSearchQuery] = useState("")
  const [court, setCourt] = useState("")
  const [year, setYear] = useState("")
  const [category, setCategory] = useState("")
  const [isSearching, setIsSearching] = useState(false)
  const [searchResults, setSearchResults] = useState<any[]>([])

  const handleSearch = async () => {
    if (!searchQuery.trim() && !court && !year && !category) return

    setIsSearching(true)
    try {
      const results = await searchCaseLaws({
        query: searchQuery,
        court,
        year,
        category,
      })
      setSearchResults(results)
    } catch (error) {
      console.error("Error searching cases:", error)
      setSearchResults([])
    } finally {
      setIsSearching(false)
    }
  }

  const displayResults = searchResults.length > 0 ? searchResults : []

  return (
    <div className="space-y-10">
      <div className="text-center mb-16">
        <div className="flex items-center justify-center gap-4 mb-8">
          <div className="p-3 bg-gradient-to-br from-red-600 to-red-700 rounded-2xl">
            <Search className="h-12 w-12 text-white" />
          </div>
          <h2 className="text-5xl font-bold bg-gradient-to-r from-red-600 to-red-800 bg-clip-text text-transparent">
            Case Law Search
          </h2>
        </div>
        <p className="text-muted-foreground max-w-4xl mx-auto text-xl leading-relaxed">
          Search through comprehensive database of Indian Supreme Court and High Court judgments. Find relevant case
          laws, precedents, legal principles, and detailed case analysis with facts, ratio, and significance.
        </p>
      </div>

      {/* Enhanced Search Filters */}
      <Card className="p-6 lg:p-10 bg-gradient-to-br from-white via-slate-50 to-white dark:from-slate-800 dark:via-slate-900 dark:to-slate-800 shadow-xl border-0">
        <div className="space-y-4 lg:space-y-0 lg:grid lg:grid-cols-5 lg:gap-8">
          <div className="lg:col-span-2">
            <Input
              placeholder="Search cases, judges, legal principles..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full h-12 lg:h-14 text-base lg:text-lg px-4 lg:px-6 border-2 focus:border-red-500"
              onKeyPress={(e) => e.key === "Enter" && handleSearch()}
            />
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 lg:gap-0 lg:contents">
            <Select value={court} onValueChange={setCourt}>
              <SelectTrigger className="h-12 lg:h-14 text-sm lg:text-lg border-2">
                <SelectValue placeholder="Court" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="supreme">Supreme Court</SelectItem>
                <SelectItem value="delhi">Delhi High Court</SelectItem>
                <SelectItem value="bombay">Bombay High Court</SelectItem>
                <SelectItem value="calcutta">Calcutta High Court</SelectItem>
                <SelectItem value="madras">Madras High Court</SelectItem>
                <SelectItem value="karnataka">Karnataka High Court</SelectItem>
                <SelectItem value="allahabad">Allahabad High Court</SelectItem>
              </SelectContent>
            </Select>
            <Select value={year} onValueChange={setYear}>
              <SelectTrigger className="h-12 lg:h-14 text-sm lg:text-lg border-2">
                <SelectValue placeholder="Year" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="2024">2024</SelectItem>
                <SelectItem value="2023">2023</SelectItem>
                <SelectItem value="2022">2022</SelectItem>
                <SelectItem value="2021">2021</SelectItem>
                <SelectItem value="2020">2020</SelectItem>
                <SelectItem value="2018">2018</SelectItem>
                <SelectItem value="2017">2017</SelectItem>
                <SelectItem value="1997">1997</SelectItem>
                <SelectItem value="1992">1992</SelectItem>
                <SelectItem value="1985">1985</SelectItem>
                <SelectItem value="1980">1980</SelectItem>
                <SelectItem value="1978">1978</SelectItem>
                <SelectItem value="1973">1973</SelectItem>
              </SelectContent>
            </Select>
            <div className="col-span-2 lg:col-span-1">
              <Button
                onClick={handleSearch}
                disabled={isSearching}
                className="w-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 h-12 lg:h-14 text-base lg:text-lg px-6 lg:px-8 shadow-lg"
              >
                {isSearching ? (
                  <Loader2 className="h-5 w-5 lg:h-6 lg:w-6 animate-spin" />
                ) : (
                  <>
                    <Search className="h-5 w-5 lg:h-6 lg:w-6 mr-2 lg:mr-3" />
                    <span className="hidden sm:inline">Search</span>
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>

        <div className="flex gap-2 lg:gap-4 mt-6 lg:mt-8 flex-wrap">
          {[
            { label: "Constitutional Law", value: "constitutional" },
            { label: "Criminal Law", value: "criminal" },
            { label: "Civil Law", value: "civil" },
            { label: "Family Law", value: "family" },
            { label: "Women Rights", value: "women" },
            { label: "Corporate Law", value: "corporate" },
          ].map((cat) => (
            <Badge
              key={cat.value}
              variant={category === cat.value ? "default" : "outline"}
              className={`cursor-pointer px-3 lg:px-6 py-2 lg:py-3 text-sm lg:text-base transition-all hover:scale-105 ${
                category === cat.value
                  ? "bg-red-600 hover:bg-red-700"
                  : "hover:bg-red-50 hover:border-red-300 dark:hover:bg-red-950/20"
              }`}
              onClick={() => {
                setCategory(category === cat.value ? "" : cat.value)
                if (searchQuery || court || year) handleSearch()
              }}
            >
              {cat.label}
            </Badge>
          ))}
        </div>
      </Card>

      {/* Search Results */}
      {displayResults.length > 0 && (
        <div className="space-y-8">
          <div className="flex items-center justify-between">
            <h3 className="text-3xl font-semibold">Search Results</h3>
            <Badge variant="secondary" className="px-6 py-3 text-lg">
              {displayResults.length} cases found
            </Badge>
          </div>

          {displayResults.map((case_, index) => (
            <Card
              key={index}
              className="p-6 lg:p-10 hover:shadow-2xl transition-all duration-500 bg-gradient-to-br from-white via-slate-50 to-white dark:from-slate-800 dark:via-slate-900 dark:to-slate-800 border-0 shadow-lg hover:scale-[1.02]"
            >
              <div className="space-y-6 lg:space-y-8">
                <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-4">
                  <div className="flex-1">
                    <h4 className="text-xl lg:text-2xl font-bold text-red-700 dark:text-red-400 mb-4 lg:mb-6 leading-tight">
                      {case_.title}
                    </h4>
                    <div className="flex flex-col sm:flex-row sm:items-center gap-4 lg:gap-8 text-base lg:text-lg text-muted-foreground mb-4 lg:mb-6">
                      <div className="flex items-center gap-2 lg:gap-3">
                        <MapPin className="h-4 w-4 lg:h-6 lg:w-6 text-red-600 flex-shrink-0" />
                        <span className="font-medium text-sm lg:text-base">{case_.court}</span>
                      </div>
                      <div className="flex items-center gap-2 lg:gap-3">
                        <Calendar className="h-4 w-4 lg:h-6 lg:w-6 text-red-600 flex-shrink-0" />
                        <span className="font-medium text-sm lg:text-base">{case_.year}</span>
                      </div>
                      <div className="flex items-center gap-2 lg:gap-3">
                        <BookOpen className="h-4 w-4 lg:h-6 lg:w-6 text-red-600 flex-shrink-0" />
                        <span className="font-medium text-sm lg:text-base break-all">{case_.citation}</span>
                      </div>
                    </div>
                    <Badge
                      variant="outline"
                      className="mb-4 lg:mb-6 px-3 lg:px-4 py-1 lg:py-2 text-sm lg:text-base border-red-200 text-red-700"
                    >
                      {case_.category}
                    </Badge>
                  </div>
                  <Button
                    variant="outline"
                    size="lg"
                    className="h-10 lg:h-12 px-4 lg:px-6 border-2 hover:border-red-500 w-full lg:w-auto"
                  >
                    <ExternalLink className="h-4 w-4 lg:h-5 lg:w-5 mr-2" />
                    <span className="text-sm lg:text-base">View Full Text</span>
                  </Button>
                </div>

                <div className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-950/20 dark:to-indigo-950/20 p-6 rounded-xl">
                  <h5 className="font-semibold mb-3 text-lg flex items-center gap-2">
                    <FileText className="h-5 w-5 text-blue-600" />
                    Case Summary
                  </h5>
                  <p className="text-base leading-relaxed">{case_.summary}</p>
                </div>

                {case_.facts && (
                  <div className="bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-950/20 dark:to-emerald-950/20 p-6 rounded-xl">
                    <h5 className="font-semibold mb-3 text-lg flex items-center gap-2">
                      <Scale className="h-5 w-5 text-green-600" />
                      Facts of the Case
                    </h5>
                    <p className="text-base leading-relaxed">{case_.facts}</p>
                  </div>
                )}

                {case_.ratio && (
                  <div className="bg-gradient-to-r from-purple-50 to-violet-50 dark:from-purple-950/20 dark:to-violet-950/20 p-6 rounded-xl">
                    <h5 className="font-semibold mb-3 text-lg flex items-center gap-2">
                      <BookOpen className="h-5 w-5 text-purple-600" />
                      Ratio Decidendi (Legal Principle)
                    </h5>
                    <p className="text-base leading-relaxed font-medium">{case_.ratio}</p>
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div>
                    <h5 className="font-semibold mb-4 text-lg">Relevant Constitutional Provisions</h5>
                    <div className="flex flex-wrap gap-3">
                      {case_.relevantSections.map((section: string, idx: number) => (
                        <Badge
                          key={idx}
                          variant="secondary"
                          className="text-sm px-4 py-2 bg-orange-100 text-orange-800 dark:bg-orange-950/20 dark:text-orange-400"
                        >
                          {section}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h5 className="font-semibold mb-4 text-lg">Bench Composition</h5>
                    <div className="flex flex-wrap gap-3">
                      {case_.judges.map((judge: string, idx: number) => (
                        <Badge key={idx} variant="outline" className="text-sm px-4 py-2 border-gray-300">
                          <Users className="h-3 w-3 mr-1" />
                          {judge}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>

                <div>
                  <h5 className="font-semibold mb-4 text-lg">Key Legal Principles Established</h5>
                  <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {case_.keyPoints.slice(0, 6).map((point: string, idx: number) => (
                      <li key={idx} className="flex items-start gap-3 text-base">
                        <span className="text-red-600 mt-2 text-xl font-bold">•</span>
                        <span className="leading-relaxed">{point}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {case_.significance && (
                  <div className="bg-gradient-to-r from-yellow-50 to-amber-50 dark:from-yellow-950/20 dark:to-amber-950/20 p-6 rounded-xl">
                    <h5 className="font-semibold mb-3 text-lg flex items-center gap-2">
                      <Scale className="h-5 w-5 text-yellow-600" />
                      Historical Significance
                    </h5>
                    <p className="text-base leading-relaxed">{case_.significance}</p>
                  </div>
                )}
              </div>
            </Card>
          ))}
        </div>
      )}

      {searchResults.length === 0 && !isSearching && (
        <div className="text-center py-20">
          <div className="p-6 bg-gradient-to-br from-red-100 to-red-200 dark:from-red-950/20 dark:to-red-900/20 rounded-full w-32 h-32 mx-auto mb-8 flex items-center justify-center">
            <Search className="h-16 w-16 text-red-600" />
          </div>
          <h3 className="text-2xl font-semibold mb-4">Start Your Legal Research</h3>
          <p className="text-muted-foreground text-lg mb-8 max-w-2xl mx-auto">
            Enter keywords, case names, legal principles, or browse by category to find relevant Indian case laws and
            judgments.
          </p>
          <Button
            onClick={() => handleSearch()}
            className="bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 px-8 py-3 text-lg"
          >
            Browse All Cases
          </Button>
        </div>
      )}
    </div>
  )
}
