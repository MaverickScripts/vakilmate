"use client"

import { useState, useEffect } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  Scale,
  MessageSquare,
  FileText,
  Search,
  BookOpen,
  Users,
  TrendingUp,
  Star,
  Zap,
  Brain,
  Database,
  Shield,
  CheckCircle,
  ArrowRight,
  Sparkles,
  Globe,
  Heart,
} from "lucide-react"
import LegalAnalyzer from "@/components/legal-analyzer"
import LegalChatbot from "@/components/legal-chatbot"
import CaseLawSearch from "@/components/case-law-search"
import DocumentGenerator from "@/components/document-generator"
import LegalResearch from "@/components/legal-research"
import { ThemeToggle } from "@/components/theme-toggle"

export default function Home() {
  const [activeTab, setActiveTab] = useState("analyzer")
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  const features = [
    {
      icon: Brain,
      title: "AI Legal Analysis",
      description: "Advanced AI-powered analysis of legal documents with accurate IPC section identification",
      color: "from-blue-500 to-blue-600",
      bgColor: "bg-blue-50 dark:bg-blue-950/20",
    },
    {
      icon: MessageSquare,
      title: "Legal Chatbot",
      description: "24/7 AI assistant with comprehensive Indian law knowledge and instant responses",
      color: "from-green-500 to-green-600",
      bgColor: "bg-green-50 dark:bg-green-950/20",
    },
    {
      icon: Database,
      title: "Case Law Database",
      description: "Comprehensive database of landmark Indian Supreme Court and High Court cases",
      color: "from-purple-500 to-purple-600",
      bgColor: "bg-purple-50 dark:bg-purple-950/20",
    },
    {
      icon: FileText,
      title: "Document Generator",
      description: "Generate professional legal documents, contracts, and templates instantly",
      color: "from-orange-500 to-orange-600",
      bgColor: "bg-orange-50 dark:bg-orange-950/20",
    },
  ]

  const stats = [
    { label: "Legal Cases", value: "50,000+", icon: TrendingUp, color: "text-blue-600" },
    { label: "IPC Sections", value: "500+", icon: BookOpen, color: "text-green-600" },
    { label: "Active Users", value: "10,000+", icon: Users, color: "text-purple-600" },
    { label: "Accuracy Rate", value: "99%", icon: Star, color: "text-orange-600" },
  ]

  const benefits = [
    "Accurate legal analysis and advice",
    "Comprehensive case law research",
    "Professional document generation",
    "24/7 AI legal assistance",
    "Precise IPC section identification",
    "Free legal guidance platform",
  ]

  if (!mounted) return null

  return (
    <div className="min-h-screen">
      {/* Enhanced Header */}
      <header className="sticky top-0 z-50 glass-card border-b">
        <div className="container-custom">
          <div className="flex items-center justify-between py-4">
            <div className="flex items-center gap-4">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-red-600 to-red-700 rounded-2xl blur opacity-75"></div>
                <div className="relative p-3 bg-gradient-to-r from-red-600 to-red-700 rounded-2xl">
                  <Scale className="h-8 w-8 text-white" />
                </div>
              </div>
              <div>
                <h1 className="text-3xl font-display font-bold gradient-text">Vakil Mate</h1>
                <p className="text-sm text-muted-foreground font-medium">Advanced Indian Legal Assistant</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Badge className="bg-gradient-to-r from-green-500 to-green-600 text-white px-4 py-2 shadow-lg">
                <Zap className="h-4 w-4 mr-2" />
                AI Powered
              </Badge>
              <ThemeToggle />
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="section-padding relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-red-50 via-white to-blue-50 dark:from-red-950/10 dark:via-slate-900 dark:to-blue-950/10"></div>
        <div className="container-custom relative">
          <div className="text-center max-w-5xl mx-auto">
            <div className="slide-up">
              <Badge className="mb-8 bg-gradient-to-r from-red-600 to-red-700 text-white px-6 py-3 text-lg shadow-xl">
                <Sparkles className="h-5 w-5 mr-2" />🚀 Now with Advanced AI Features
              </Badge>
            </div>

            <h2 className="slide-up delay-100 text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-display font-bold mb-6 lg:mb-8 leading-tight">
              Your Complete <span className="gradient-text">Legal AI</span> Assistant
            </h2>

            <p className="slide-up delay-200 text-lg sm:text-xl lg:text-2xl text-muted-foreground mb-8 lg:mb-12 leading-relaxed max-w-4xl mx-auto px-4">
              Analyze legal documents with precision, chat with our brilliant AI legal expert, search comprehensive case
              laws, and generate professional legal documents - all powered by advanced AI and comprehensive Indian
              legal database.
            </p>

            <div className="slide-up delay-300 flex flex-wrap justify-center gap-4 mb-16">
              {benefits.map((benefit, index) => (
                <div
                  key={index}
                  className="flex items-center gap-2 bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm px-4 py-2 rounded-full border transition-all duration-300 hover:scale-105"
                >
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <span className="text-sm font-medium">{benefit}</span>
                </div>
              ))}
            </div>

            {/* Feature Cards */}
            <div className="slide-up delay-400 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
              {features.map((feature, index) => (
                <div key={index} className={`feature-card ${feature.bgColor} group`}>
                  <div
                    className={`p-4 rounded-2xl bg-gradient-to-br ${feature.color} mb-6 w-fit mx-auto group-hover:scale-110 transition-transform duration-300`}
                  >
                    <feature.icon className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="font-display font-semibold mb-4 text-xl">{feature.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
                </div>
              ))}
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
              {stats.map((stat, index) => (
                <div key={index} className="stat-card group">
                  <stat.icon
                    className={`h-8 w-8 mx-auto mb-4 ${stat.color} group-hover:scale-110 transition-transform duration-300`}
                  />
                  <div className="text-3xl font-display font-bold text-gray-900 dark:text-white mb-2">{stat.value}</div>
                  <div className="text-sm text-muted-foreground font-medium">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Main Application */}
      <section className="section-padding bg-gradient-to-br from-slate-50 via-white to-blue-50 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900">
        <div className="container-custom">
          <div className="glass-card rounded-3xl overflow-hidden shadow-2xl">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <div className="bg-gradient-to-r from-slate-50 via-white to-slate-50 dark:from-slate-800 dark:via-slate-900 dark:to-slate-800 p-8 border-b">
                <TabsList className="grid w-full grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 h-12 sm:h-14 lg:h-16 bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm shadow-lg rounded-xl lg:rounded-2xl p-1 lg:p-2">
                  <TabsTrigger
                    value="analyzer"
                    className="flex items-center gap-1 sm:gap-2 lg:gap-3 data-[state=active]:bg-gradient-to-r data-[state=active]:from-red-600 data-[state=active]:to-red-700 data-[state=active]:text-white rounded-lg lg:rounded-xl transition-all duration-300 font-semibold text-xs sm:text-sm lg:text-base px-2 lg:px-4"
                  >
                    <Brain className="h-4 w-4 lg:h-5 lg:w-5" />
                    <span className="hidden sm:inline">AI Analyzer</span>
                    <span className="sm:hidden">Analyzer</span>
                  </TabsTrigger>
                  <TabsTrigger
                    value="chatbot"
                    className="flex items-center gap-1 sm:gap-2 lg:gap-3 data-[state=active]:bg-gradient-to-r data-[state=active]:from-red-600 data-[state=active]:to-red-700 data-[state=active]:text-white rounded-lg lg:rounded-xl transition-all duration-300 font-semibold text-xs sm:text-sm lg:text-base px-2 lg:px-4"
                  >
                    <MessageSquare className="h-4 w-4 lg:h-5 lg:w-5" />
                    <span className="hidden sm:inline">Legal Chat</span>
                    <span className="sm:hidden">Chat</span>
                  </TabsTrigger>
                  <TabsTrigger
                    value="search"
                    className="flex items-center gap-1 sm:gap-2 lg:gap-3 data-[state=active]:bg-gradient-to-r data-[state=active]:from-red-600 data-[state=active]:to-red-700 data-[state=active]:text-white rounded-lg lg:rounded-xl transition-all duration-300 font-semibold text-xs sm:text-sm lg:text-base px-2 lg:px-4"
                  >
                    <Search className="h-4 w-4 lg:h-5 lg:w-5" />
                    <span className="hidden lg:inline">Case Search</span>
                    <span className="lg:hidden">Search</span>
                  </TabsTrigger>
                  <TabsTrigger
                    value="generator"
                    className="flex items-center gap-1 sm:gap-2 lg:gap-3 data-[state=active]:bg-gradient-to-r data-[state=active]:from-red-600 data-[state=active]:to-red-700 data-[state=active]:text-white rounded-lg lg:rounded-xl transition-all duration-300 font-semibold text-xs sm:text-sm lg:text-base px-2 lg:px-4"
                  >
                    <FileText className="h-4 w-4 lg:h-5 lg:w-5" />
                    <span className="hidden lg:inline">Doc Generator</span>
                    <span className="lg:hidden">Docs</span>
                  </TabsTrigger>
                  <TabsTrigger
                    value="research"
                    className="flex items-center gap-1 sm:gap-2 lg:gap-3 data-[state=active]:bg-gradient-to-r data-[state=active]:from-red-600 data-[state=active]:to-red-700 data-[state=active]:text-white rounded-lg lg:rounded-xl transition-all duration-300 font-semibold text-xs sm:text-sm lg:text-base px-2 lg:px-4"
                  >
                    <BookOpen className="h-4 w-4 lg:h-5 lg:w-5" />
                    <span className="hidden sm:inline">Research</span>
                    <span className="sm:hidden">Research</span>
                  </TabsTrigger>
                </TabsList>
              </div>

              <div className="p-8 lg:p-12">
                <TabsContent value="analyzer" className="mt-0">
                  <LegalAnalyzer />
                </TabsContent>

                <TabsContent value="chatbot" className="mt-0">
                  <LegalChatbot />
                </TabsContent>

                <TabsContent value="search" className="mt-0">
                  <CaseLawSearch />
                </TabsContent>

                <TabsContent value="generator" className="mt-0">
                  <DocumentGenerator />
                </TabsContent>

                <TabsContent value="research" className="mt-0">
                  <LegalResearch />
                </TabsContent>
              </div>
            </Tabs>
          </div>
        </div>
      </section>

      {/* Enhanced Footer */}
      <footer className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white section-padding">
        <div className="container-custom">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12 mb-8 lg:mb-12">
            <div className="md:col-span-2 lg:col-span-2">
              <div className="flex items-center gap-3 lg:gap-4 mb-4 lg:mb-6">
                <div className="p-2 lg:p-3 bg-gradient-to-r from-red-600 to-red-700 rounded-xl lg:rounded-2xl">
                  <Scale className="h-6 w-6 lg:h-8 lg:w-8 text-white" />
                </div>
                <span className="text-2xl lg:text-3xl font-display font-bold">Vakil Mate</span>
              </div>
              <p className="text-slate-300 leading-relaxed mb-4 lg:mb-6 text-sm lg:text-base max-w-md">
                Advanced AI-powered legal assistant for Indian law practitioners and citizens. Get instant legal
                guidance, analyze documents, and research case laws with cutting-edge technology.
              </p>
              <div className="flex flex-wrap items-center gap-3 lg:gap-4">
                <Badge className="bg-green-600 text-white px-3 py-1 text-xs lg:text-sm">
                  <Globe className="h-3 w-3 lg:h-4 lg:w-4 mr-1 lg:mr-2" />
                  Available 24/7
                </Badge>
                <Badge className="bg-blue-600 text-white px-3 py-1 text-xs lg:text-sm">
                  <Shield className="h-3 w-3 lg:h-4 lg:w-4 mr-1 lg:mr-2" />
                  Secure & Private
                </Badge>
              </div>
            </div>

            <div>
              <h3 className="font-display font-semibold mb-4 lg:mb-6 text-lg lg:text-xl">Features</h3>
              <ul className="space-y-2 lg:space-y-3 text-slate-300 text-sm lg:text-base">
                <li className="flex items-center gap-2">
                  <ArrowRight className="h-3 w-3 lg:h-4 lg:w-4 text-red-500 flex-shrink-0" />
                  <span>Legal Document Analysis</span>
                </li>
                <li className="flex items-center gap-2">
                  <ArrowRight className="h-3 w-3 lg:h-4 lg:w-4 text-red-500 flex-shrink-0" />
                  <span>AI Legal Chatbot</span>
                </li>
                <li className="flex items-center gap-2">
                  <ArrowRight className="h-3 w-3 lg:h-4 lg:w-4 text-red-500 flex-shrink-0" />
                  <span>Case Law Search</span>
                </li>
                <li className="flex items-center gap-2">
                  <ArrowRight className="h-3 w-3 lg:h-4 lg:w-4 text-red-500 flex-shrink-0" />
                  <span>Document Generation</span>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-display font-semibold mb-4 lg:mb-6 text-lg lg:text-xl">Legal Areas</h3>
              <ul className="space-y-2 lg:space-y-3 text-slate-300 text-sm lg:text-base">
                <li className="flex items-center gap-2">
                  <ArrowRight className="h-3 w-3 lg:h-4 lg:w-4 text-red-500 flex-shrink-0" />
                  <span>Criminal Law</span>
                </li>
                <li className="flex items-center gap-2">
                  <ArrowRight className="h-3 w-3 lg:h-4 lg:w-4 text-red-500 flex-shrink-0" />
                  <span>Constitutional Law</span>
                </li>
                <li className="flex items-center gap-2">
                  <ArrowRight className="h-3 w-3 lg:h-4 lg:w-4 text-red-500 flex-shrink-0" />
                  <span>Civil Law</span>
                </li>
                <li className="flex items-center gap-2">
                  <ArrowRight className="h-3 w-3 lg:h-4 lg:w-4 text-red-500 flex-shrink-0" />
                  <span>Corporate Law</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-slate-700 pt-6 lg:pt-8">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <p className="text-slate-400 text-xs lg:text-sm text-center sm:text-left">
                &copy; 2024 Vakil Mate. All rights reserved. This tool is for informational purposes only.
              </p>
              <div className="flex items-center gap-2">
                <Heart className="h-4 w-4 text-red-500" />
                <span className="text-slate-400 text-xs lg:text-sm">Built by Shreyas Chowdhury</span>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
