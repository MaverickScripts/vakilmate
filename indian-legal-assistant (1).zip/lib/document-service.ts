import { HfInference } from "@huggingface/inference"

const hf = new HfInference("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")

export async function generateDocument(documentType: string, formData: Record<string, string>) {
  try {
    // First try AI generation for dynamic content
    const prompt = `Generate a professional ${documentType.replace("-", " ")} document with the following details: ${JSON.stringify(formData)}. Make it legally sound and properly formatted for Indian law.`

    let aiGeneratedContent = ""
    try {
      const response = await hf.textGeneration({
        model: "gpt2",
        inputs: prompt,
        parameters: {
          max_length: 500,
          temperature: 0.7,
        },
      })
      aiGeneratedContent = response.generated_text || ""
    } catch (aiError) {
      console.error("AI generation failed, using template:", aiError)
    }

    // Fallback to comprehensive templates
    switch (documentType) {
      case "legal-notice":
        return generateLegalNotice(formData, aiGeneratedContent)
      case "affidavit":
        return generateAffidavit(formData, aiGeneratedContent)
      case "rental-agreement":
        return generateRentalAgreement(formData, aiGeneratedContent)
      case "power-of-attorney":
        return generatePowerOfAttorney(formData, aiGeneratedContent)
      case "employment-contract":
        return generateEmploymentContract(formData, aiGeneratedContent)
      case "nda":
        return generateNDA(formData, aiGeneratedContent)
      default:
        return "Document type not supported yet."
    }
  } catch (error) {
    console.error("Error generating document:", error)
    throw error
  }
}

function generateLegalNotice(data: Record<string, string>, aiContent: string) {
  const currentDate = new Date().toLocaleDateString("en-IN")

  return `LEGAL NOTICE

To,
${data.recipientName || "[Recipient Name]"}
${data.recipientAddress || "[Recipient Address]"}

Subject: ${data.subject || "Legal Notice"}

Sir/Madam,

I, ${data.senderName || "[Sender Name]"}, residing at ${data.senderAddress || "[Sender Address]"}, through this legal notice, bring to your attention the following facts and circumstances:

FACTS OF THE CASE:
${data.details || "Please provide details of the issue that necessitates this legal notice. Include relevant dates, events, and circumstances that led to this situation."}

LEGAL GROUNDS:
The above-mentioned acts/omissions on your part constitute a violation of legal rights and are actionable under the relevant provisions of law. Your conduct is in breach of the legal obligations and has caused significant loss, damage, and mental agony.

DEMAND:
You are hereby called upon to ${data.demand || "take appropriate action to remedy the situation"} within 15 (fifteen) days from the receipt of this notice, failing which my client shall be constrained to initiate appropriate legal proceedings against you for:

1. Recovery of the damages/compensation
2. Interest on the amount due
3. Costs of the legal proceedings
4. Any other relief deemed fit by the Hon'ble Court

LEGAL CONSEQUENCES:
Take notice that if you fail to comply with the above demand within the stipulated time, my client shall be left with no alternative but to approach the competent court of law for appropriate relief. You shall be liable for all costs, consequences, and damages arising therefrom.

This notice is issued under the provisions of Section 80 of the Code of Civil Procedure, 1908, and other applicable laws.

Yours faithfully,

${data.senderName || "[Sender Name]"}

Date: ${currentDate}
Place: [Place]

Note: This is a legal document. Please treat it with due seriousness and respond within the stipulated time frame.

---
${aiContent ? `AI Enhancement: ${aiContent.substring(0, 200)}...` : ""}`
}

function generateAffidavit(data: Record<string, string>, aiContent: string) {
  const currentDate = new Date().toLocaleDateString("en-IN")

  return `AFFIDAVIT

I, ${data.deponentName || "[Deponent Name]"}, aged [Age] years, son/daughter of [Father's Name], residing at ${data.deponentAddress || "[Deponent Address]"}, do hereby solemnly affirm and declare as under:

1. That I am the deponent herein and I am competent to swear this affidavit.

2. That the facts stated herein are true and correct to the best of my knowledge and belief and nothing material has been concealed therefrom.

3. PURPOSE: ${data.purpose || "The purpose of this affidavit is to [state the purpose clearly]"}

4. STATEMENT OF FACTS:
${data.facts || "I hereby state the following facts under oath: [Provide detailed facts and circumstances that need to be sworn to. Each fact should be numbered and clearly stated.]"}

5. That I have not filed any other affidavit in respect of the same matter before any other authority.

6. That I undertake to inform the concerned authority if there is any change in the facts stated above.

7. That I am executing this affidavit for the purpose of ${data.purpose || "[state purpose]"} and for no other purpose.

8. That the contents of this affidavit are true to the best of my knowledge and belief and nothing has been concealed therein.

DEPONENT

VERIFICATION:
I, the above-named deponent, do hereby verify that the contents of the above affidavit are true and correct to the best of my knowledge and belief and no part of it is false and nothing material has been concealed therefrom.

Verified at [Place] on this ${currentDate}.

                                                    DEPONENT
                                            ${data.deponentName || "[Deponent Name]"}

---
NOTARIZATION:
Sworn before me and signed in my presence on ${currentDate} at [Place].

                                                    NOTARY PUBLIC
                                                    [Notary Name]
                                                    [Notary Seal]

${aiContent ? `\nAI Enhancement: ${aiContent.substring(0, 200)}...` : ""}`
}

function generateRentalAgreement(data: Record<string, string>, aiContent: string) {
  const currentDate = new Date().toLocaleDateString("en-IN")

  return `RENTAL AGREEMENT

This Rental Agreement is made on ${currentDate} between:

LANDLORD: ${data.landlordName || "[Landlord Name]"}, residing at [Landlord Address]
(hereinafter referred to as "Landlord")

AND

TENANT: ${data.tenantName || "[Tenant Name]"}, residing at [Tenant Address]
(hereinafter referred to as "Tenant")

PROPERTY DETAILS:
The property located at: ${data.propertyAddress || "[Property Address]"}
(hereinafter referred to as "Premises")

TERMS AND CONDITIONS:

1. LEASE PERIOD: The lease period shall be ${data.leasePeriod || "11 months"} commencing from [Start Date] to [End Date].

2. RENT: The monthly rent for the premises is Rs. ${data.rentAmount || "[Amount]"}/- (Rupees [Amount in words] only) payable in advance by the 5th of each month.

3. SECURITY DEPOSIT: The tenant shall pay a security deposit of Rs. ${data.securityDeposit || "[Amount]"}/- (Rupees [Amount in words] only) which shall be refunded at the time of vacating the premises, subject to deductions for any damages.

4. UTILITIES: The tenant shall be responsible for payment of electricity, water, gas, and other utility bills.

5. MAINTENANCE: The tenant shall maintain the premises in good condition and shall not make any structural changes without written consent of the landlord.

6. SUBLETTING: The tenant shall not sublet or assign the premises to any third party without written consent of the landlord.

7. TERMINATION: Either party may terminate this agreement by giving one month's written notice.

8. REGISTRATION: This agreement shall be registered as per the applicable laws.

9. JURISDICTION: Any disputes arising out of this agreement shall be subject to the jurisdiction of courts in [City].

IN WITNESS WHEREOF, both parties have executed this agreement on the date mentioned above.

LANDLORD                                    TENANT
${data.landlordName || "[Landlord Name]"}                     ${data.tenantName || "[Tenant Name]"}

WITNESSES:
1. _________________                        2. _________________
   [Name & Signature]                          [Name & Signature]

${aiContent ? `\nAI Enhancement: ${aiContent.substring(0, 200)}...` : ""}`
}

function generatePowerOfAttorney(data: Record<string, string>, aiContent: string) {
  const currentDate = new Date().toLocaleDateString("en-IN")

  return `POWER OF ATTORNEY

KNOW ALL MEN BY THESE PRESENTS that I, ${data.principalName || "[Principal Name]"}, aged [Age] years, son/daughter of [Father's Name], residing at ${data.principalAddress || "[Principal Address]"}, do hereby nominate, constitute and appoint ${data.attorneyName || "[Attorney Name]"}, aged [Age] years, son/daughter of [Father's Name], residing at ${data.attorneyAddress || "[Attorney Address]"}, as my true and lawful attorney to act for me and in my name and on my behalf.

SCOPE OF AUTHORITY:
My said attorney is hereby authorized to:

1. ${data.powers || "Represent me in all legal matters"}
2. Sign documents on my behalf
3. Appear before government authorities
4. Handle banking transactions (if applicable)
5. Execute agreements and contracts
6. File applications and petitions
7. Collect documents and certificates
8. Do all acts and things necessary for the above purposes

DURATION:
This Power of Attorney shall remain in force until revoked by me in writing.

RATIFICATION:
I hereby ratify and confirm all acts done by my said attorney in pursuance of this Power of Attorney.

IN WITNESS WHEREOF, I have executed this Power of Attorney on ${currentDate}.

                                                    PRINCIPAL
                                            ${data.principalName || "[Principal Name]"}

WITNESSES:
1. _________________                        2. _________________
   [Name & Signature]                          [Name & Signature]

ACCEPTANCE:
I, ${data.attorneyName || "[Attorney Name]"}, do hereby accept the above Power of Attorney and undertake to act in the best interests of the Principal.

                                                    ATTORNEY
                                            ${data.attorneyName || "[Attorney Name]"}

${aiContent ? `\nAI Enhancement: ${aiContent.substring(0, 200)}...` : ""}`
}

function generateEmploymentContract(data: Record<string, string>, aiContent: string) {
  const currentDate = new Date().toLocaleDateString("en-IN")

  return `EMPLOYMENT AGREEMENT

This Employment Agreement is entered into on ${currentDate} between:

EMPLOYER: ${data.companyName || "[Company Name]"}
Address: ${data.companyAddress || "[Company Address]"}
(hereinafter referred to as "Company")

AND

EMPLOYEE: ${data.employeeName || "[Employee Name]"}
Address: ${data.employeeAddress || "[Employee Address]"}
(hereinafter referred to as "Employee")

TERMS OF EMPLOYMENT:

1. POSITION: The Employee is appointed as ${data.designation || "[Designation]"} in the Company.

2. COMMENCEMENT: Employment shall commence from ${data.startDate || "[Start Date]"}.

3. SALARY: The Employee shall receive a monthly salary of Rs. ${data.salary || "[Amount]"}/- (Rupees [Amount in words] only).

4. WORKING HOURS: Normal working hours shall be [X] hours per day, [X] days per week.

5. PROBATION: The Employee shall be on probation for ${data.probationPeriod || "6 months"}.

6. CONFIDENTIALITY: The Employee shall maintain strict confidentiality of company information.

7. TERMINATION: Either party may terminate employment by giving ${data.noticePeriod || "30 days"} written notice.

8. BENEFITS: The Employee shall be entitled to benefits as per company policy.

9. GOVERNING LAW: This agreement shall be governed by Indian laws.

IN WITNESS WHEREOF, both parties have executed this agreement.

COMPANY                                     EMPLOYEE
${data.companyName || "[Company Name]"}                      ${data.employeeName || "[Employee Name]"}

By: _________________                       _________________
    [Authorized Signatory]                     [Employee Signature]

Date: ${currentDate}

${aiContent ? `\nAI Enhancement: ${aiContent.substring(0, 200)}...` : ""}`
}

function generateNDA(data: Record<string, string>, aiContent: string) {
  const currentDate = new Date().toLocaleDateString("en-IN")

  return `NON-DISCLOSURE AGREEMENT (NDA)

This Non-Disclosure Agreement is entered into on ${currentDate} between:

DISCLOSING PARTY: ${data.disclosingParty || "[Disclosing Party Name]"}
Address: ${data.disclosingAddress || "[Address]"}

AND

RECEIVING PARTY: ${data.receivingParty || "[Receiving Party Name]"}
Address: ${data.receivingAddress || "[Address]"}

WHEREAS, the parties wish to explore potential business opportunities and may disclose confidential information;

NOW THEREFORE, the parties agree as follows:

1. CONFIDENTIAL INFORMATION: Any information disclosed by either party that is marked as confidential or would reasonably be considered confidential.

2. OBLIGATIONS: The Receiving Party agrees to:
   - Keep all confidential information strictly confidential
   - Not disclose to any third party without written consent
   - Use information solely for evaluation purposes
   - Return all materials upon request

3. DURATION: This agreement shall remain in effect for ${data.duration || "2 years"} from the date hereof.

4. EXCEPTIONS: This agreement does not apply to information that:
   - Is publicly available
   - Was known prior to disclosure
   - Is independently developed
   - Is required to be disclosed by law

5. REMEDIES: Breach of this agreement may result in irreparable harm, entitling the injured party to seek injunctive relief.

6. GOVERNING LAW: This agreement shall be governed by Indian laws.

IN WITNESS WHEREOF, the parties have executed this agreement.

DISCLOSING PARTY                            RECEIVING PARTY
${data.disclosingParty || "[Name]"}                          ${data.receivingParty || "[Name]"}

_________________                           _________________
[Signature]                                 [Signature]

Date: ${currentDate}

${aiContent ? `\nAI Enhancement: ${aiContent.substring(0, 200)}...` : ""}`
}
