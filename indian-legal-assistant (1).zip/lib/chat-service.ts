import { HfInference } from "@huggingface/inference"

const hf = new HfInference("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")

interface Message {
  content: string
  role: "user" | "assistant"
}

export async function generateChatResponse(userMessage: string, previousMessages: any[]) {
  try {
    // Comprehensive legal knowledge base with accurate Indian law information
    const legalKnowledgeBase = {
      procedures: {
        fir: {
          keywords: ["fir", "first information report", "police complaint", "lodge complaint"],
          response: `**How to File an FIR (First Information Report):**

📋 **Step-by-Step Process:**
1. **Visit the nearest police station** in the jurisdiction where the offense occurred
2. **Provide written complaint** or give oral information to the duty officer
3. **Police must register FIR** for all cognizable offenses under Section 154 CrPC
4. **Get a copy of the FIR** with FIR number and date
5. **Follow up regularly** on the investigation progress

⚖️ **Legal Requirements:**
• Police cannot refuse to register FIR for cognizable offenses
• FIR must be registered immediately upon receiving information
• You have the right to get a free copy of the FIR
• If police refuse, approach the Superintendent of Police or Magistrate

🔍 **Important Points:**
• FIR can be filed by anyone, not just the victim
• Online FIR facility available in many states
• Zero FIR can be filed at any police station
• Time limit: No specific time limit, but should be filed promptly

📞 **Emergency:** Call 100 for immediate police assistance`,
        },
        bail: {
          keywords: ["bail", "anticipatory bail", "regular bail", "interim bail"],
          response: `**Bail in Indian Criminal Law:**

🔓 **Types of Bail:**
1. **Regular Bail** - Applied after arrest (Section 437 CrPC)
2. **Anticipatory Bail** - Pre-arrest bail (Section 438 CrPC)
3. **Interim Bail** - Temporary bail pending regular bail application
4. **Default Bail** - Automatic bail if chargesheet not filed in time

⚖️ **Bail Procedure:**
1. **File bail application** in appropriate court (Magistrate/Sessions/High Court)
2. **Submit supporting documents** and grounds for bail
3. **Appear on hearing date** with lawyer
4. **If granted, furnish bail bond** with surety
5. **Comply with bail conditions** strictly

🏛️ **Court Jurisdiction:**
• **Magistrate Court** - For offenses punishable up to 7 years
• **Sessions Court** - For serious offenses and anticipatory bail
• **High Court** - For non-bailable offenses and when lower court refuses

📋 **Bail Conditions:**
• Regular attendance in court
• Not to tamper with evidence or witnesses
• Not to leave jurisdiction without permission
• Surrender passport (if applicable)

💡 **Important:** File application immediately when arrest is apprehended`,
        },
        consumer: {
          keywords: ["consumer complaint", "consumer court", "consumer forum", "deficiency in service"],
          response: `**Consumer Complaint Filing Process:**

🏛️ **Consumer Forums Hierarchy:**
1. **District Consumer Forum** - Complaints up to ₹20 lakhs
2. **State Consumer Commission** - ₹20 lakhs to ₹1 crore
3. **National Consumer Commission** - Above ₹1 crore

📋 **Filing Procedure:**
1. **Prepare complaint** with all relevant documents
2. **Pay prescribed fees** (varies by complaint value)
3. **Submit to appropriate forum** within jurisdiction
4. **Attend hearings** as scheduled
5. **Await judgment** and compensation

⏰ **Time Limits:**
• **2 years** from the date of cause of action
• **3 years** in case of continuing cause of action
• Court may condone delay with sufficient cause

💰 **Fees Structure:**
• Up to ₹1 lakh - ₹200
• ₹1-5 lakhs - ₹400
• ₹5-10 lakhs - ₹750
• Above ₹10 lakhs - ₹5,000

🎯 **What You Can Claim:**
• Refund of amount paid
• Compensation for loss/damage
• Punitive damages
• Removal of defects in goods
• Discontinuation of unfair trade practices`,
        },
      },
      ipcSections: {
        "302": {
          keywords: ["section 302", "murder", "302 ipc", "punishment for murder"],
          response: `**Section 302 IPC - Punishment for Murder:**

⚖️ **Legal Provision:**
"Whoever commits murder shall be punished with death, or imprisonment for life, and shall also be liable to fine."

🔍 **Essential Elements:**
1. **Intention to cause death** OR
2. **Knowledge that act is likely to cause death**
3. **Causing death** by doing such act

⚖️ **Punishment:**
• **Death penalty** (in rarest of rare cases)
• **Life imprisonment** (usual punishment)
• **Fine** (additional punishment)

🏛️ **Court Details:**
• **Cognizable:** Yes (police can arrest without warrant)
• **Bailable:** No
• **Triable by:** Sessions Court only
• **Investigation:** Mandatory post-mortem, forensic evidence

📚 **Related Sections:**
• Section 300 - Definition of Murder
• Section 299 - Culpable Homicide
• Section 304 - Culpable Homicide not amounting to Murder

🎯 **Defenses Available:**
• Grave and sudden provocation (Exception 1 to Section 300)
• Self-defense (Section 96-106)
• Insanity (Section 84)
• Intoxication (Section 85-86)

📖 **Landmark Cases:**
• Bachan Singh vs State of Punjab (Rarest of rare doctrine)
• Machhi Singh vs State of Punjab (Guidelines for death penalty)`,
        },
        "420": {
          keywords: ["section 420", "cheating", "420 ipc", "fraud", "dishonestly inducing"],
          response: `**Section 420 IPC - Cheating and Dishonestly Inducing Delivery of Property:**

⚖️ **Legal Provision:**
"Whoever cheats and thereby dishonestly induces the person deceived to deliver any property..."

🔍 **Essential Elements:**
1. **Cheating** as defined in Section 415
2. **Dishonest inducement** to deliver property
3. **Actual delivery** of property by the deceived person
4. **Deception** by the accused

⚖️ **Punishment:**
• **Imprisonment** up to 7 years (simple or rigorous)
• **Fine** (discretionary)
• **Both** imprisonment and fine

🏛️ **Court Details:**
• **Cognizable:** No (police cannot arrest without warrant)
• **Bailable:** Yes
• **Triable by:** Magistrate of First Class
• **Compoundable:** No

📚 **Related Sections:**
• Section 415 - Definition of Cheating
• Section 417 - Punishment for Cheating
• Section 419 - Cheating by Personation
• Section 421 - Dishonest or Fraudulent Removal of Property

🎯 **Common Examples:**
• Online fraud and cyber cheating
• Fake investment schemes
• Counterfeit goods selling
• Identity theft for financial gain
• Fake job offer scams

💡 **Prevention Tips:**
• Verify credentials before transactions
• Be cautious of too-good-to-be-true offers
• Report suspicious activities immediately`,
        },
        "498a": {
          keywords: ["section 498a", "dowry harassment", "cruelty", "498a ipc", "domestic violence"],
          response: `**Section 498A IPC - Husband or Relative Subjecting Woman to Cruelty:**

⚖️ **Legal Provision:**
"Whoever, being the husband or the relative of the husband of a woman, subjects such woman to cruelty shall be punished..."

🔍 **Definition of Cruelty:**
1. **Willful conduct** likely to drive woman to suicide
2. **Grave injury** or danger to life, limb or health
3. **Harassment for dowry** demands

⚖️ **Punishment:**
• **Imprisonment** up to 3 years
• **Fine** (discretionary)
• **Both** imprisonment and fine

🏛️ **Court Details:**
• **Cognizable:** Yes
• **Bailable:** No
• **Triable by:** Magistrate of First Class
• **Investigation:** Mandatory under Section 174 CrPC

📚 **Related Provisions:**
• Section 304B IPC - Dowry Death
• Section 113A Evidence Act - Presumption as to abetment of suicide
• Section 113B Evidence Act - Presumption as to dowry death
• Dowry Prohibition Act, 1961

🛡️ **Protection Available:**
• Immediate arrest of accused
• Protection under Domestic Violence Act, 2005
• Maintenance under Section 125 CrPC
• Shelter home facilities

⚠️ **Important Notes:**
• Complaint can be filed by woman or her relatives
• Medical evidence crucial in physical cruelty cases
• Court may order counseling before trial
• Misuse provisions also exist - false cases punishable`,
        },
      },
      rights: {
        accused: {
          keywords: ["rights of accused", "accused rights", "fundamental rights", "arrest rights"],
          response: `**Rights of Accused Person in India:**

🛡️ **Fundamental Rights (Constitution):**
• **Article 20** - Protection against ex-post-facto laws and double jeopardy
• **Article 21** - Right to life and personal liberty
• **Article 22** - Protection against arbitrary arrest and detention

⚖️ **Rights During Investigation:**
1. **Right to remain silent** (Article 20(3))
2. **Right to legal representation** from the time of arrest
3. **Right to be informed** of grounds of arrest
4. **Right to be produced** before magistrate within 24 hours
5. **Right to medical examination** if demanded

🏛️ **Rights During Trial:**
• **Right to fair trial** and speedy justice
• **Right to cross-examine** prosecution witnesses
• **Right to examine** defense witnesses
• **Right to appeal** against conviction
• **Presumption of innocence** until proven guilty

📞 **Legal Aid Rights:**
• **Free legal aid** if unable to afford lawyer (Article 39A)
• **Legal Services Authority** assistance
• **Duty counsel** in sessions court

🔍 **Rights in Custody:**
• **Right against torture** and custodial violence
• **Right to inform** family/friends about arrest
• **Right to meet lawyer** in private
• **Right to bail** (in bailable offenses)

💡 **Remember:** These rights are guaranteed by Constitution and cannot be violated by police or courts`,
        },
      },
      courts: {
        hierarchy: {
          keywords: ["court system", "hierarchy", "jurisdiction", "supreme court", "high court"],
          response: `**Indian Court System Hierarchy:**

🏛️ **Supreme Court of India (Apex Court):**
• **Jurisdiction:** Constitutional matters, appeals from High Courts
• **Judges:** Chief Justice + 33 other judges
• **Powers:** Constitutional interpretation, final court of appeal

🏛️ **High Courts (State Level):**
• **25 High Courts** across India
• **Jurisdiction:** State matters, appeals from subordinate courts
• **Powers:** Writ jurisdiction, constitutional matters

⚖️ **District Courts:**
• **Civil Jurisdiction:** Money suits, property disputes
• **Criminal Jurisdiction:** Sessions cases (serious crimes)
• **Family Courts:** Marriage, divorce, custody matters

🏛️ **Subordinate Courts:**

**Criminal Side:**
• **Chief Judicial Magistrate** - Serious criminal cases
• **Judicial Magistrate First Class** - Cases up to 3 years imprisonment
• **Judicial Magistrate Second Class** - Cases up to 1 year imprisonment

**Civil Side:**
• **Senior Civil Judge** - Suits up to ₹20 lakhs
• **Junior Civil Judge** - Suits up to ₹5 lakhs
• **Munsif Court** - Small money suits

🎯 **Special Courts:**
• **Fast Track Courts** - Speedy disposal
• **Commercial Courts** - Commercial disputes
• **Family Courts** - Matrimonial matters
• **Consumer Courts** - Consumer disputes
• **Cyber Crime Courts** - Technology-related crimes

📍 **Jurisdiction Rules:**
• **Territorial** - Where cause of action arose
• **Pecuniary** - Based on value of suit/severity of offense
• **Subject Matter** - Type of case (civil/criminal/constitutional)`,
        },
      },
    }

    // Enhanced keyword matching with context understanding
    const message = userMessage.toLowerCase()
    let response = ""
    let matchFound = false

    // Check procedures
    for (const [key, data] of Object.entries(legalKnowledgeBase.procedures)) {
      if (data.keywords.some((keyword) => message.includes(keyword))) {
        response = data.response
        matchFound = true
        break
      }
    }

    // Check IPC sections
    if (!matchFound) {
      for (const [key, data] of Object.entries(legalKnowledgeBase.ipcSections)) {
        if (data.keywords.some((keyword) => message.includes(keyword))) {
          response = data.response
          matchFound = true
          break
        }
      }
    }

    // Check rights
    if (!matchFound) {
      for (const [key, data] of Object.entries(legalKnowledgeBase.rights)) {
        if (data.keywords.some((keyword) => message.includes(keyword))) {
          response = data.response
          matchFound = true
          break
        }
      }
    }

    // Check courts
    if (!matchFound) {
      for (const [key, data] of Object.entries(legalKnowledgeBase.courts)) {
        if (data.keywords.some((keyword) => message.includes(keyword))) {
          response = data.response
          matchFound = true
          break
        }
      }
    }

    // Specific legal queries
    if (!matchFound) {
      if (message.includes("anticipatory bail")) {
        response = `**Anticipatory Bail (Section 438 CrPC):**

🔓 **What is Anticipatory Bail?**
Pre-arrest bail granted when a person apprehends arrest in a non-bailable offense.

⚖️ **Who Can Grant:**
• **High Court** - Has inherent power
• **Sessions Court** - As per state amendments

📋 **Procedure:**
1. **File application** before anticipated arrest
2. **Show reasonable grounds** for apprehension
3. **Court may impose conditions** like:
   - Cooperation in investigation
   - Not to tamper with evidence
   - Regular reporting to police

⏰ **Duration:**
• No fixed time limit in law
• Court's discretion based on case progress
• Can be cancelled if conditions violated

🚫 **Limitations:**
• Not available for certain serious offenses (varies by state)
• Court may refuse if case involves:
  - Heinous crimes
  - Repeat offenders
  - Public order concerns

💡 **Important:** File application immediately when arrest is apprehended`
      } else if (message.includes("cognizable") || message.includes("non-cognizable")) {
        response = `**Cognizable vs Non-Cognizable Offenses:**

🚨 **Cognizable Offenses:**
• **Police can arrest** without warrant
• **Investigation** starts without court permission
• **Examples:** Murder, rape, theft, kidnapping, dowry death
• **Serious crimes** generally cognizable

📋 **Non-Cognizable Offenses:**
• **Police cannot arrest** without warrant
• **Court permission** required for investigation
• **Examples:** Cheating, defamation, simple hurt
• **Less serious offenses** generally non-cognizable

⚖️ **Key Differences:**

| Aspect | Cognizable | Non-Cognizable |
|--------|------------|----------------|
| Arrest | Without warrant | With warrant only |
| Investigation | Immediate | Court permission needed |
| FIR | Mandatory | Not mandatory |
| Bail | Usually non-bailable | Usually bailable |

📚 **Legal Basis:**
• **First Schedule** of CrPC lists all offenses
• **Column 2** indicates if cognizable or not
• **Police powers** defined accordingly

💡 **Practical Tip:** Check First Schedule CrPC for specific offense classification`
      } else if (message.includes("bailable") || message.includes("non-bailable")) {
        response = `**Bailable vs Non-Bailable Offenses:**

🔓 **Bailable Offenses:**
• **Right to bail** - Court must grant if conditions met
• **Police can grant bail** at station level
• **Examples:** Simple theft, cheating, simple hurt
• **Less serious crimes** generally bailable

🔒 **Non-Bailable Offenses:**
• **Discretionary bail** - Court's decision
• **Police cannot grant bail** - Only court can
• **Examples:** Murder, rape, dowry death, terrorism
• **Serious crimes** generally non-bailable

⚖️ **Bail Considerations for Non-Bailable Offenses:**
1. **Nature and gravity** of offense
2. **Character of evidence** against accused
3. **Reasonable apprehension** of:
   - Tampering with evidence
   - Influencing witnesses
   - Fleeing from justice

📋 **Court's Discretion Factors:**
• **Previous criminal record**
• **Likelihood of conviction**
• **Public interest and safety**
• **Health and age** of accused
• **Duration of custody**

💡 **Remember:** Even in non-bailable cases, bail can be granted if prosecution fails to file chargesheet within prescribed time (60-90 days)`
      } else if (
        message.includes("hello") ||
        message.includes("hi") ||
        message.includes("help") ||
        message.includes("namaste")
      ) {
        response = `🙏 **Namaste! Welcome to Vakil Mate**

I'm your AI Legal Assistant specializing in Indian law. I can help you with:

📋 **Legal Procedures:**
• Filing FIR and police complaints
• Bail applications and procedures
• Consumer complaint filing
• Court procedures and jurisdiction

⚖️ **Criminal Law:**
• IPC sections and punishments
• Rights of accused persons
• Cognizable vs non-cognizable offenses
• Bailable vs non-bailable offenses

🏛️ **Court System:**
• Court hierarchy and jurisdiction
• Legal procedures and timelines
• Appeal processes

🛡️ **Legal Rights:**
• Fundamental rights during arrest
• Consumer rights and protection
• Women's rights and protection laws

💡 **How to use:**
Simply ask me questions like:
• "How to file an FIR?"
• "Explain Section 302 IPC"
• "What are rights of accused?"
• "Difference between cognizable and non-cognizable"

**What legal question can I help you with today?**`
      } else {
        // Generic helpful response with suggestions
        response = `I understand you're asking about "${userMessage}". 

While I don't have specific information on this exact topic, I can help you with:

📋 **Legal Procedures:**
• FIR filing and police complaints
• Bail applications and procedures  
• Consumer complaint filing
• Court procedures

⚖️ **Criminal Law:**
• IPC sections (302, 420, 498A, etc.)
• Rights of accused persons
• Legal definitions and procedures

🏛️ **Court System:**
• Court hierarchy and jurisdiction
• Legal procedures and timelines

**Try asking:**
• "How to file FIR?"
• "Explain Section 302 IPC"
• "Rights of accused person"
• "Consumer complaint procedure"
• "Court system in India"

Could you please rephrase your question or ask about a specific legal procedure, IPC section, or legal right?

**⚠️ Disclaimer:** This information is for educational purposes only and does not constitute legal advice. Please consult a qualified lawyer for specific legal matters.`
      }
    }

    // Add disclaimer to all responses if not already present
    if (!response.includes("Disclaimer") && !response.includes("educational purposes")) {
      response +=
        "\n\n**⚠️ Disclaimer:** This information is for educational purposes only and does not constitute legal advice. Please consult a qualified lawyer for specific legal matters."
    }

    return response
  } catch (error) {
    console.error("Error generating chat response:", error)
    return "I apologize, but I'm experiencing technical difficulties. Please try again in a moment. For urgent legal matters, please consult with a qualified lawyer immediately.\n\n**⚠️ Disclaimer:** This information is for educational purposes only and does not constitute legal advice."
  }
}
