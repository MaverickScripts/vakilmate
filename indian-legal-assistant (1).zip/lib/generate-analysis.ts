export async function generateLegalAnalysis(input: string) {
  try {
    // Enhanced legal analysis with comprehensive IPC knowledge
    const lowerInput = input.toLowerCase()

    let crimeDetected = false
    const crimes: string[] = []
    const ipcSections: any[] = []
    let explanation = ""
    let possibleDefenses: string[] = []
    let legalAdvice = ""

    // Comprehensive crime detection patterns
    const crimePatterns = {
      murder: {
        keywords: ["murder", "kill", "killed", "death", "homicide", "shot", "stabbed", "poisoned", "strangled"],
        section: "Section 302 IPC",
        description: "Punishment for murder - Death or life imprisonment with fine",
        crime: "Murder",
      },
      theft: {
        keywords: ["steal", "theft", "stolen", "rob", "robbed", "robbery", "burglary", "pickpocket"],
        section: "Section 378 IPC",
        description: "Theft - Imprisonment up to 3 years or fine or both",
        crime: "Theft",
      },
      cheating: {
        keywords: ["cheat", "fraud", "deceive", "fake", "counterfeit", "scam", "embezzle"],
        section: "Section 420 IPC",
        description: "Cheating and dishonestly inducing delivery of property - Imprisonment up to 7 years with fine",
        crime: "Cheating",
      },
      assault: {
        keywords: ["assault", "attack", "beat", "hit", "punch", "slap", "hurt", "injury"],
        section: "Section 322 IPC",
        description: "Voluntarily causing hurt - Imprisonment up to 1 year or fine up to ₹1000 or both",
        crime: "Assault/Hurt",
      },
      threat: {
        keywords: ["threat", "threaten", "intimidate", "blackmail", "extort"],
        section: "Section 506 IPC",
        description: "Criminal intimidation - Imprisonment up to 2 years or fine or both",
        crime: "Criminal Intimidation",
      },
      rape: {
        keywords: ["rape", "sexual assault", "molestation", "sexual harassment"],
        section: "Section 376 IPC",
        description: "Rape - Rigorous imprisonment not less than 10 years, may extend to life imprisonment",
        crime: "Rape/Sexual Assault",
      },
      dowry: {
        keywords: ["dowry", "dowry harassment", "dowry death", "cruelty", "domestic violence"],
        section: "Section 498A IPC",
        description: "Cruelty by husband or relatives - Imprisonment up to 3 years with fine",
        crime: "Dowry Harassment/Domestic Violence",
      },
      kidnapping: {
        keywords: ["kidnap", "abduct", "forcibly take", "unlawful detention"],
        section: "Section 363 IPC",
        description: "Kidnapping - Imprisonment up to 7 years with fine",
        crime: "Kidnapping",
      },
      bribery: {
        keywords: ["bribe", "corruption", "illegal gratification", "kickback"],
        section: "Section 7 Prevention of Corruption Act",
        description: "Taking bribe - Imprisonment 6 months to 5 years with fine",
        crime: "Bribery/Corruption",
      },
      defamation: {
        keywords: ["defame", "defamation", "false accusation", "character assassination", "slander"],
        section: "Section 499 IPC",
        description: "Defamation - Simple imprisonment up to 2 years or fine or both",
        crime: "Defamation",
      },
    }

    // Analyze input for crimes
    for (const [crimeType, pattern] of Object.entries(crimePatterns)) {
      if (pattern.keywords.some((keyword) => lowerInput.includes(keyword))) {
        crimeDetected = true
        crimes.push(pattern.crime)
        ipcSections.push({
          section: pattern.section,
          description: pattern.description,
        })
      }
    }

    // Generate comprehensive analysis
    if (crimeDetected) {
      explanation = `Based on the facts provided, the following criminal offense(s) have been identified under the Indian Penal Code:

${crimes.map((crime, index) => `${index + 1}. **${crime}**: ${ipcSections[index]?.description}`).join("\n")}

**Legal Analysis:**
The described actions constitute criminal behavior under Indian law. The prosecution would need to prove the essential elements of each offense beyond reasonable doubt.`

      // Generate specific defenses based on crime type
      if (crimes.includes("Murder")) {
        possibleDefenses = [
          "Self-defense under Section 96-106 IPC",
          "Grave and sudden provocation (Exception 1 to Section 300)",
          "Lack of intention to cause death",
          "Insanity at the time of offense (Section 84 IPC)",
          "Intoxication affecting mental capacity (Section 85-86 IPC)",
        ]
      } else if (crimes.includes("Theft")) {
        possibleDefenses = [
          "Lack of dishonest intention",
          "Claim of right or good faith belief in ownership",
          "Consent of the owner",
          "Mistake of fact (Section 79 IPC)",
          "Alibi - not present at the scene",
        ]
      } else if (crimes.includes("Cheating")) {
        possibleDefenses = [
          "No intention to deceive",
          "Full disclosure of material facts",
          "Victim's knowledge of true facts",
          "Good faith transaction",
          "Lack of dishonest inducement",
        ]
      } else {
        possibleDefenses = [
          "Lack of mens rea (criminal intent)",
          "Alibi defense",
          "Self-defense (where applicable)",
          "Consent of the victim (where applicable)",
          "Mistake of fact or law",
        ]
      }

      legalAdvice = `**Immediate Legal Steps:**

1. **Consult a Criminal Lawyer** immediately for case-specific advice
2. **Preserve all evidence** including documents, photographs, and witness details
3. **Do not make any statements** to police without legal representation
4. **Apply for bail** if arrest is likely (anticipatory bail for non-bailable offenses)
5. **Gather character witnesses** and supporting documents

**Important Considerations:**
• Cooperate with investigation while protecting your rights
• Maintain detailed records of all legal proceedings
• Consider mediation/compromise where legally permissible
• Understand the difference between cognizable and non-cognizable offenses

**Court Procedures:**
• FIR registration (for cognizable offenses)
• Police investigation and chargesheet filing
• Framing of charges by Magistrate
• Trial proceedings and evidence presentation
• Judgment and possible appeal options`
    } else {
      explanation =
        "Based on the analysis of the provided information, no clear criminal offense appears to have been committed under the Indian Penal Code. However, this assessment is based on limited information and a detailed legal review may reveal other aspects."

      legalAdvice = `**Recommended Actions:**

1. **Consult a qualified lawyer** for comprehensive legal review
2. **Document all relevant facts** and circumstances
3. **Preserve any evidence** that might be relevant
4. **Consider civil remedies** if applicable (breach of contract, tort, etc.)
5. **Explore alternative dispute resolution** methods like mediation

**Preventive Measures:**
• Ensure all future transactions are properly documented
• Understand your legal rights and obligations
• Seek legal advice before entering into significant agreements
• Maintain proper records of all important communications`
    }

    // Generate comprehensive summary
    const summary = `Legal Analysis Summary: ${
      crimeDetected
        ? `Potential criminal liability identified under ${crimes.length} offense(s). ` +
          `Primary charges may include ${crimes.join(", ")}. ` +
          `Immediate legal consultation recommended for defense strategy.`
        : `No apparent criminal liability under Indian Penal Code based on provided information. ` +
          `Civil or regulatory issues may still exist requiring legal review.`
    }`

    return {
      summary,
      crimeDetected,
      crimes: crimes.length > 0 ? crimes : undefined,
      ipcSections: ipcSections.length > 0 ? ipcSections : undefined,
      explanation,
      possibleDefenses: possibleDefenses.length > 0 ? possibleDefenses : undefined,
      legalAdvice,
      references: [
        "Indian Penal Code, 1860",
        "Code of Criminal Procedure, 1973",
        "Indian Evidence Act, 1872",
        "Constitution of India (Fundamental Rights)",
      ],
    }
  } catch (error) {
    console.error("Error generating legal analysis:", error)
    return {
      summary: "Error occurred during analysis. Please try again with more specific details.",
      crimeDetected: false,
      explanation:
        "Unable to process the request at this time. Please ensure you provide clear factual details for accurate legal analysis.",
      legalAdvice:
        "For any legal matter, it is always advisable to consult with a qualified criminal lawyer who can provide case-specific guidance based on complete facts and circumstances.",
    }
  }
}
