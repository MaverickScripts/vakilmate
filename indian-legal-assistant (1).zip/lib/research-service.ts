import { HfInference } from "@huggingface/inference"

const hf = new HfInference("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")

export async function searchLegalContent(query: string) {
  try {
    // Comprehensive legal database
    const legalDatabase = {
      ipcSections: [
        {
          section: "Section 302",
          title: "Punishment for murder",
          description:
            "Whoever commits murder shall be punished with death, or imprisonment for life, and shall also be liable to fine.",
          category: "Offences against the Human Body",
          chapter: "Chapter XVI",
          punishment: "Death or Life Imprisonment + Fine",
          cognizable: "Yes",
          bailable: "No",
          triableBy: "Court of Session",
          relatedSections: ["300", "301", "303", "304", "304A"],
          ingredients: [
            "Intention to cause death",
            "Knowledge that act is likely to cause death",
            "Causing death by doing act with such intention or knowledge",
          ],
          exceptions: ["Grave and sudden provocation", "Self-defense", "Insanity"],
          landmarkCases: ["Machhi Singh v State of Punjab", "Bachan Singh v State of Punjab"],
        },
        {
          section: "Section 420",
          title: "Cheating and dishonestly inducing delivery of property",
          description:
            "Whoever cheats and thereby dishonestly induces the person deceived to deliver any property to any person, or to make, alter or destroy the whole or any part of a valuable security, shall be punished with imprisonment of either description for a term which may extend to seven years, and shall also be liable to fine.",
          category: "Of Cheating",
          chapter: "Chapter XVII",
          punishment: "Imprisonment up to 7 years + Fine",
          cognizable: "No",
          bailable: "Yes",
          triableBy: "Magistrate of First Class",
          relatedSections: ["415", "416", "417", "418", "419", "421"],
          ingredients: [
            "Cheating as defined in Section 415",
            "Dishonestly inducing delivery of property",
            "Deception of the victim",
          ],
          exceptions: ["Consent obtained without deception", "Good faith transactions"],
          landmarkCases: ["State of Maharashtra v Dr. Praful B. Desai", "Hridaya Ranjan Prasad Verma v State of Bihar"],
        },
        {
          section: "Section 498A",
          title: "Husband or relative of husband subjecting woman to cruelty",
          description:
            "Whoever, being the husband or the relative of the husband of a woman, subjects such woman to cruelty shall be punished with imprisonment for a term which may extend to three years and shall also be liable to fine.",
          category: "Offences against Women",
          chapter: "Chapter XX",
          punishment: "Imprisonment up to 3 years + Fine",
          cognizable: "Yes",
          bailable: "No",
          triableBy: "Magistrate of First Class",
          relatedSections: ["304B", "306", "113A", "113B"],
          ingredients: [
            "Husband or relative of husband",
            "Subjecting woman to cruelty",
            "Cruelty as defined in explanation",
          ],
          exceptions: ["Reasonable disciplinary action", "Acts done in good faith"],
          landmarkCases: ["Sushil Kumar Sharma v Union of India", "Arnesh Kumar v State of Bihar"],
        },
      ],
      procedures: [
        {
          title: "Filing an FIR",
          description: "First Information Report filing procedure under CrPC",
          steps: [
            "Approach nearest police station",
            "Provide written complaint or oral information",
            "Police must register FIR for cognizable offenses",
            "Obtain copy of FIR",
            "Follow up on investigation",
          ],
          legalBasis: "Section 154 CrPC",
          timeLimit: "Immediately upon receiving information",
          applicableTo: "Cognizable offenses",
        },
        {
          title: "Bail Application",
          description: "Procedure for applying for bail in criminal cases",
          steps: [
            "File bail application in appropriate court",
            "Submit supporting documents",
            "Appear before court on hearing date",
            "Furnish bail bond and surety",
            "Comply with bail conditions",
          ],
          legalBasis: "Sections 436-450 CrPC",
          timeLimit: "No specific time limit",
          applicableTo: "Accused persons in custody",
        },
      ],
      acts: [
        {
          name: "Indian Penal Code, 1860",
          description: "Main criminal law of India",
          totalSections: 511,
          chapters: 23,
          keyFeatures: ["Defines crimes and punishments", "Applies throughout India", "Substantive criminal law"],
        },
        {
          name: "Code of Criminal Procedure, 1973",
          description: "Procedural law for criminal cases",
          totalSections: 484,
          chapters: 37,
          keyFeatures: ["Investigation procedure", "Trial procedure", "Appeal and revision"],
        },
      ],
    }

    // Search through the database
    const results: any[] = []
    const searchTerm = query.toLowerCase()

    // Search IPC sections
    legalDatabase.ipcSections.forEach((section) => {
      if (
        section.section.toLowerCase().includes(searchTerm) ||
        section.title.toLowerCase().includes(searchTerm) ||
        section.description.toLowerCase().includes(searchTerm) ||
        section.category.toLowerCase().includes(searchTerm)
      ) {
        results.push({
          type: "IPC Section",
          ...section,
        })
      }
    })

    // Search procedures
    legalDatabase.procedures.forEach((procedure) => {
      if (
        procedure.title.toLowerCase().includes(searchTerm) ||
        procedure.description.toLowerCase().includes(searchTerm)
      ) {
        results.push({
          type: "Legal Procedure",
          ...procedure,
        })
      }
    })

    // Search acts
    legalDatabase.acts.forEach((act) => {
      if (act.name.toLowerCase().includes(searchTerm) || act.description.toLowerCase().includes(searchTerm)) {
        results.push({
          type: "Legal Act",
          ...act,
        })
      }
    })

    // If no results found, try AI-powered search
    if (results.length === 0) {
      try {
        const aiResponse = await hf.textGeneration({
          model: "gpt2",
          inputs: `Explain the Indian legal concept: ${query}. Provide relevant IPC sections and legal principles.`,
          parameters: {
            max_length: 300,
            temperature: 0.7,
          },
        })

        results.push({
          type: "AI Generated",
          title: `Legal Information: ${query}`,
          description: aiResponse.generated_text || "AI-generated legal information based on your search query.",
          source: "AI Analysis",
          note: "This is AI-generated content. Please verify with official legal sources.",
        })
      } catch (aiError) {
        console.error("AI search failed:", aiError)
      }
    }

    return results.length > 0
      ? results
      : [
          {
            type: "No Results",
            title: "No matching results found",
            description: `No legal content found for "${query}". Try different keywords or browse our legal database.`,
            suggestions: [
              "Try broader search terms",
              "Check spelling",
              "Browse IPC sections",
              "Consult legal databases",
            ],
          },
        ]
  } catch (error) {
    console.error("Error searching legal content:", error)
    throw error
  }
}

export async function getIPCSectionDetails(sectionNumber: string) {
  // Detailed IPC section information
  const ipcDetails: Record<string, any> = {
    "302": {
      section: "Section 302",
      title: "Punishment for murder",
      fullText:
        "Whoever commits murder shall be punished with death, or imprisonment for life, and shall also be liable to fine.",
      explanation: "This section deals with the punishment for murder. Murder is defined in Section 300 of IPC.",
      essentialElements: [
        "Intention to cause death",
        "Knowledge that the act is likely to cause death",
        "Causing death by doing an act with such intention or knowledge",
      ],
      punishment: "Death penalty or life imprisonment with fine",
      cognizable: true,
      bailable: false,
      compoundable: false,
      triableBy: "Court of Session",
      relatedSections: ["300", "301", "303", "304"],
      exceptions: ["Grave and sudden provocation", "Self-defense", "Insanity"],
      illustrations: [
        "A shoots B with intention to kill him. B dies. A is guilty of murder.",
        "A knowing that a loaded gun is pointed at B, pulls the trigger. B dies. A is guilty of murder.",
      ],
      landmarkJudgments: [
        "Machhi Singh v State of Punjab - Guidelines for death penalty",
        "Bachan Singh v State of Punjab - Rarest of rare doctrine",
      ],
    },
    "420": {
      section: "Section 420",
      title: "Cheating and dishonestly inducing delivery of property",
      fullText:
        "Whoever cheats and thereby dishonestly induces the person deceived to deliver any property to any person, or to make, alter or destroy the whole or any part of a valuable security, or anything which is signed or sealed, and which is capable of being converted into a valuable security, shall be punished with imprisonment of either description for a term which may extend to seven years, and shall also be liable to fine.",
      explanation:
        "This section punishes cheating when it results in delivery of property. Cheating is defined in Section 415.",
      essentialElements: [
        "Cheating as defined in Section 415",
        "Dishonestly inducing delivery of property",
        "Deception of the victim",
      ],
      punishment: "Imprisonment up to 7 years with fine",
      cognizable: false,
      bailable: true,
      compoundable: false,
      triableBy: "Magistrate of First Class",
      relatedSections: ["415", "416", "417", "418", "419"],
      exceptions: ["Consent without deception", "Good faith transactions"],
      illustrations: [
        "A sells counterfeit goods as genuine to B. A is guilty under Section 420.",
        "A obtains money from B by falsely representing his financial status. A commits offense under Section 420.",
      ],
      landmarkJudgments: [
        "State of Maharashtra v Dr. Praful B. Desai - Elements of cheating",
        "Hridaya Ranjan Prasad Verma v State of Bihar - Dishonest intention",
      ],
    },
  }

  return ipcDetails[sectionNumber] || null
}
